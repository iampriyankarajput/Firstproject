/*******************************************************************************
 * Put Server and Plugins configs here
 * ENV: Development
 ******************************************************************************/
'use strict';
const path = require('path');
const projectName = 'Huulke Sales CMS';
const port = 6015;

module.exports = {
    env: 'development',
    server: {
        host: '127.0.0.1',
        port: port
    },
    product: {
        name: projectName
    },
    key: {
        privateKey: 'BbZJjyoXAdr8BUZuiKKARWimKfrSmQ6fv8kZ7OFfc'
    },
    db: {
        url: 'mongodb://34.245.6.31:27017/huulke-sales-db',
        options: {
            useMongoClient: true
        }
    },
    mysql: {
        host: '34.254.206.185',
        username: 'huulke',
        password: 'Huulkeindia@123',
        database: 'epushserver',
        timezone: '-05:30',
        diffTime: '05:30',
        upDown: '-'
    },
    languages: ['en', 'it', 'fr', 'de'],
    languagesText: {
        'en': 'English',
        'it': 'Italian',
        'fr': 'French',
        'de': 'German'
    },
    platformFrom: ['Main Huulke', 'Huulke Tech', 'Metodo Huulke', 'Dream In Team'],
    thankYouMessage: {
        'en': '<h3>Thank You</h3><br/><p>We have received your message and would like to thank you for writing to us.</p><br/><p>We will get back to you shortly.</p>'
    },
    s3: {
       AWS_ACCESS_KEY: "AKIAJOMOYOLGMRI2JNDQ",
       AWS_SECRET_ACCESS_KEY: "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",
       bucketName: 'main-huulke-web'
   },
   emailFooter: '<p><i class="fa fa-home"></i> 1053, B-2, Spaze i-tech Park Sohna Road, Gurgaon 1220018<br/><i class="fa fa-phone"></i> +91 9015613691<br/><i class="fa fa-envelope"></i><a href="mailto:p.baboo@huulke.com">developers@huulke.com</a></p>',
   emailOptions: {
       loginConfirm: {
           subject: 'Login Confirmation on '+projectName,
           template: 'loginNotification'
       },
   },
   Sendgrid: {
       apiKey: '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',
       from: 'Huulke CRM developers@huulke.com',
       username: 'premhuulke',
       password: 'hrhk@1234',
   },
   staticPaths: {
       uploadFile: process.cwd()+'/uploads/',
   },
   deaultSuperAdmin: {
       email: 'developers@huulke.com',
       empCode: 'HKL-01',
       password: 'Password1',
       fullName: 'Prem Baboo',
       userType: 1,
       adminType: 1,
       modulesAndpermissions: [
           {
               key: 'prospect',
               name: 'Prospects',
               selected: false,
               permissions: {
                   'R': false,
                   'W': false,
                   'D': false,
                   'U': false
               }
           },
           {
               key: 'lead',
               name: 'Leads',
               selected: false,
               permissions: {
                   'R': false,
                   'W': false,
                   'D': false,
                   'U': false
               }
           },
           {
               key: 'client',
               name: 'Clients',
               selected: false,
               permissions: {
                   'R': false,
                   'W': false,
                   'D': false,
                   'U': false
               }
           },
           {
               key: 'webcontacts',
               name: 'Web Contacts',
               selected: false,
               permissions: {
                   'R': false,
                   'W': false,
                   'D': false,
                   'U': false
               }
           },
           {
               key: 'cxos',
               name: 'Cxos',
               selected: false,
               permissions: {
                   'R': false,
                   'W': false,
                   'D': false,
                   'U': false
               }
           },
           {
               key: 'attendance',
               name: 'Attendance',
               selected: false,
               permissions: {
                   'R': false,
                   'W': false,
                   'D': false,
                   'U': false
               }
           },
           {
               key: 'leave',
               name: 'Leaves',
               selected: false,
               permissions: {
                   'R': false,
                   'W': false,
                   'D': false,
                   'U': false
               }
           },
           {
               key: 'allattendance',
               name: 'AllAttendance',
               selected: false,
               permissions: {
                   'R': false,
                   'W': false,
                   'D': false,
                   'U': false
               }
           },
           {
               key: 'holidays',
               name: 'Holidays',
               selected: false,
               permissions: {
                   'R': false,
                   'W': false,
                   'D': false,
                   'U': false
               }
           },
           {
               key: 'salary',
               name: 'Salary',
               selected: false,
               permissions: {
                   'R': false,
                   'W': false,
                   'D': false,
                   'U': false
               }
           },
           {
               key: 'event',
               name: 'Events',
               selected: false,
               permissions: {
                   'R': false,
                   'W': false,
                   'D': false,
                   'U': false
               }
           },
           {
               key: 'users',
               name: 'Users',
               selected: false,
               permissions: {
                   'R': false,
                   'W': false,
                   'D': false,
                   'U': false
               }
           },
           {
               key: 'sections',
               name: 'Sections',
               selected: false,
               permissions: {
                   'R': false,
                   'W': false,
                   'D': false,
                   'U': false
               }
           },
           {
               key: 'contacts',
               name: 'Contacts',
               selected: false,
               permissions: {
                   'R': false,
                   'W': false,
                   'D': false,
                   'U': false
               }
           },
           {
               key: 'job',
               name: 'Jobs',
               selected: false,
               permissions: {
                   'R': false,
                   'W': false,
                   'D': false,
                   'U': false
               }
           },
           {
               key: 'resume',
               name: 'Resumes',
               selected: false,
               permissions: {
                   'R': false,
                   'W': false,
                   'D': false,
                   'U': false
               }
           }
       ]
   }
};
