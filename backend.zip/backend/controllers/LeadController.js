/*******************************************************************************
 * Lead Controller
 ******************************************************************************/
'use strict';
const mongoose = require('mongoose');
const Prospect = mongoose.model('Prospect');
const Cxo = mongoose.model('Cxo');
const Q = require('q');
const Config = require('../config/config');
const moment = require('moment');
const CommonHelper = require('../helpers/common');

module.exports = {

    getLeads: function (req, res) {
        var fRes = {
            success: true,
            message: 'success',
            data: [],
            totalCount: 0
        };
        return res.status(200).send(fRes);
        var query = {},
            offset = req.query.offset ? req.query.offset : 0,
            limit = req.query.limit ? req.query.limit : 100;
        if (!query.$and) {
            query.$and = [];
        }
        if(req.query.name) {
            var name = req.query.name;
            query.$and.push({'$or': [{ name: { $regex: new RegExp("^" + name.toLowerCase(), "i") }}, { email: { $regex: new RegExp("^" + name.toLowerCase(), "i") }}, { websiteUrl: { $regex: new RegExp("^" + name, "i") }}] });
        }
        if(req.query.industry) {
            var industry = req.query.industry;
            query.$and.push({ 'industry.key': industry });
        }
        if(req.query.companySize) {
            var companySize = req.query.companySize;
            query.$and.push({ 'companySize.key': companySize });
        }
        if(req.query.section) {
            var section = req.query.section;
            query.$and.push({ section: section });
        }
        if(req.query.creator) {
            var creator = req.query.creator;
            query.$and.push({ creator: creator });
        }
        if(req.query.created_at) {
            var created_at = req.query.created_at;
            var start = new Date(created_at);
            var y = start.getFullYear();
            var m = start.getMonth()+1;
            var d = start.getDate();
            var dt = y+'-'+(m>9?m:('0'+m))+'-'+(d>9?d:('0'+d));
            var end = moment.utc(dt).endOf('day').toDate();
            query.$and.push({ updated_at: {'$gte': start, '$lte': end} });
        }
        if(req.auth.credentials.adminType != 1) {
            query.$and.push({ creator: req.auth.credentials.id });
        }
        query.$and.push({ category: 'lead' });

        Q.all([
            Prospect.count(query).exec(),
            Prospect.find(query).sort('-updated_at').populate('cxo').populate('creator').exec()
        ]).then(function (prospects) {
            var fRes = {
                success: true,
                message: 'success',
                data: prospects[1],
                totalCount: prospects[0]
            };
            res.status(200).send(fRes);
        });
    },

    getLeadDetail: function(req, res) {
        Prospect.findOne({_id: req.params.id}).populate('cxo').populate('section').populate('creator').then((prospect) => {
            if (prospect) {
                res.status(200).send({
                    success: true,
                    message: 'success',
                    data: prospect
                });
            } else {
                res.status(404).send({
                    success: false,
                    message: 'Data not found',
                    data: null
                });
            }
        });
    },
};
