/*******************************************************************************
 * Lead Controller
 ******************************************************************************/
'use strict';
const mongoose = require('mongoose');
const Holidays = mongoose.model('Holidays');
const Q = require('q');
const Config = require('../config/config');
const moment = require('moment');
const CommonHelper = require('../helpers/common');

module.exports = {

    getHolidays: function (req, res) {
        var year = new Date().getFullYear();
        Holidays.findOne({ year: year }, function (err, holidays) {
            var fRes = {
                success: true,
                message: 'success',
                data: holidays?holidays:[]
            };
            res.status(200).send(fRes);
        });
    },

    addHolidays: function(req, res) {
        var holidays = req.body.holidays;
        if(holidays && holidays.length) {
            Holidays.findOne({ year: req.params.year }, function (err, record) {
                if(record) {
                    return res.status(404).send({
                        success: false,
                        message: 'The holiday data already upload to the year: '+req.params.year+ ' so please update If you need'
                    });
                }
                var records = {
                    year: req.params.year,
                    company: req.body.company?req.body.company:'',
                    branch: req.body.branch?req.body.branch:'',
                    description: req.body.description?req.body.description:'',
                };

                var data = new Holidays(records);
                for(var i=0; i<req.body.holidays.length; i++) {
                    data.holidays.push({
                        date: req.body.holidays[i].date,
                        title: req.body.holidays[i].title,
                        type: req.body.holidays[i].type
                    });
                }
                data.save(function (err, result) {
                    if(err) {
                        return res.status(404).send({
                            success: false,
                            message: 'Invalid holiday for the year: '+req.params.year+ ' or error in import',
                            data: err
                        });
                    }
                    res.status(200).send({
                        success: true,
                        message: 'Holidays data has been imported successfully for the year: '+req.params.year,
                        data: []
                    });
                });
            });
        } else {
            res.status(404).send({
                success: false,
                message: 'Missing holidays data'
            });
        }
    },

    updateHolidays: function(req, res) {
        res.status(200).send({data: 'Thanks'});
    },
};
