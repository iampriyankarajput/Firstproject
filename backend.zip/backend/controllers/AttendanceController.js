/*******************************************************************************
 * Attendance Controller
 ******************************************************************************/
'use strict';
const mongoose = require('mongoose');
const Attendance = mongoose.model('Attendance');
const Holidays = mongoose.model('Holidays');
const Leave = mongoose.model('Leave');
const Q = require('q');
const moment = require('moment');
const Config = require('../config/config');
const GlobalConfig = require('../config/gconfig');
const CommonHelper = require('../helpers/common');
const MailHelper = require('../helpers/mail');

module.exports = {
    getEmployeeAttendance: function (req, res) {
        function getDaysInMonth(month, year) {
            var totalDays = new Date(year, month, 0).getDate();
            var wDays = [];
            for(var i=1; i<=totalDays; i++) {
                var dt = new Date(year+'-'+(month<10?('0'+month):month)+'-'+(i<10?('0'+i):i));
                var d = dt.getDay();
                if(d>0 && d<6) {
                    wDays.push(year+'-'+(month<10?('0'+month):month)+'-'+(i<10?('0'+i):i)+'T00:00:00.000Z');
                }
            }
            return {
                tds: totalDays,
                wtds: wDays
            };
        }

        var query = {},
            offset = req.query.offset ? req.query.offset : 0,
            limit = req.query.limit ? req.query.limit : 10;
        var date = new Date();
        var year = req.query.year?req.query.year:(date.getFullYear());
        var month = req.query.month?req.query.month:(date.getMonth()+1);
        var holidays = [];
        var td = getDaysInMonth(month, year);
        var otherInfo = {
            totalDays: td.tds,
            workingDays: td.wtds.length,
            holidays: 0,
            leaves: 0,
            paidLeaves: 0,
            unpaidLeave: 0
        };
        Holidays.findOne({ year: year }, function (err, hdays) {
            if(hdays && hdays.holidays.length) {
                    for(var k=1; k<=hdays.holidays.length; k++) {
                        var dmk = hdays.holidays[k-1].date.split('T')[0].split('-');
                        var mk = month<10?('0'+month):month;
                        var mk1 = dmk[1];
                        if((mk == mk1) && (hdays.holidays[k-1].type == 'holiday')) {
                            holidays.push(hdays.holidays[k]);
                        }
                    }
                otherInfo.holidays = holidays.length;
            }
        });
        if (!query.$and) {
            query.$and = [];
        }
        if(req.query.date) {
            var attDate = req.query.date;
            var start = new Date(attDate);
            var y = start.getFullYear();
            var m = start.getMonth()+1;
            var d = start.getDate();
            var dt = y+'-'+(m>9?m:('0'+m))+'-'+(d>9?d:('0'+d));
            var end = moment.utc(dt).endOf('day').toDate();
            query.$and.push({ date: {'$gte': start, '$lte': end} });
        }
        query.$and.push({ month:  month});
        query.$and.push({ year:  year});
        query.$and.push({ user: req.auth.credentials.id });

        Q.all([
            Attendance.count(query).exec(),
            Attendance.find(query).sort('-date').exec()
        ]).then(function (attendances) {
            for(var l=0; l<attendances[1].length; l++) {
                if(attendances[1][l].leaveType == 'FD') {
                    otherInfo.leaves = otherInfo.leaves + 1;
                    if(attendances[1][l].isApproved && attendances[1][l].isPaid) {
                        otherInfo.paidLeaves = otherInfo.paidLeaves + 1;
                    }
                    if( !( attendances[1][l].isApproved && attendances[1][l].isPaid) ) {
                        otherInfo.unpaidLeave = otherInfo.unpaidLeave + 1;
                    }
                }
                if(attendances[1][l].leaveType == 'HD') {
                    otherInfo.leaves = otherInfo.leaves + 0.5;
                    if(attendances[1][l].isApproved && attendances[1][l].isPaid) {
                        otherInfo.paidLeaves = otherInfo.paidLeaves + 0.5;
                    }
                    if( !( attendances[1][l].isApproved && attendances[1][l].isPaid) ) {
                        otherInfo.unpaidLeave = otherInfo.unpaidLeave + 0.5;
                    }
                }
                if(attendances[1][l].leaveType == 'SL') {
                    otherInfo.leaves = otherInfo.leaves + 0.25;
                    if(attendances[1][l].isApproved && attendances[1][l].isPaid) {
                        otherInfo.paidLeaves = otherInfo.paidLeaves + 0.25;
                    }
                    if( !( attendances[1][l].isApproved && attendances[1][l].isPaid) ) {
                        otherInfo.unpaidLeave = otherInfo.unpaidLeave + 0.25;
                    }
                }
            }
            var fRes = {
                success: true,
                message: 'success',
                data: attendances[1],
                other: otherInfo,
                totalCount: attendances[0]
            };
            res.status(200).send(fRes);
        });
    },

    getAllEmployeeAttendance: function (req, res) {
        var query = {},
            offset = req.query.offset ? req.query.offset : 0,
            limit = req.query.limit ? req.query.limit : 31;
        var date = new Date();
        var currentYear = date.getFullYear();
        var currentMonth = date.getMonth()+1;
        if (!query.$and) {
            query.$and = [];
        }
        if(req.query.date) {
            var attDate = req.query.date;
            var start = new Date(attDate);
            var y = start.getFullYear();
            var m = start.getMonth()+1;
            var d = start.getDate();
            var dt = y+'-'+(m>9?m:('0'+m))+'-'+(d>9?d:('0'+d));
            var end = moment.utc(dt).endOf('day').toDate();
            query.$and.push({ date: {'$gte': start, '$lte': end} });
        }
        if(req.query.employee) {
            query.$and.push({ user:  req.query.employee});
        }
        if(req.query.month) {
            query.$and.push({ month:  req.query.month});
        } else {
            query.$and.push({ month:  currentMonth});
        }
        if(req.query.year) {
            query.$and.push({ year:  req.query.year});
        } else {
            query.$and.push({ year:  currentYear});
        }
        Q.all([
            Attendance.count(query).exec(),
            Attendance.find(query).sort('-date').skip(parseInt(offset)).limit(parseInt(limit)).exec()
        ]).then(function (attendances) {
            var fRes = {
                success: true,
                message: 'success',
                data: attendances[1],
                totalCount: attendances[0]
            };
            res.status(200).send(fRes);
        });
    },

    updateAttendanceStatus: function(req, res) {
        var a = req.body.date.split('T')[0];
        var dt = new Date(a);
        var year = dt.getFullYear();
        var m = (dt.getMonth()+1);
        var d = dt.getDate();
        var y = year+'-'+(m<10?('0'+m):m)+'-'+(d<10?('0'+d):d)+'T00:00:00.000Z';
        var t = year+'-'+(m<10?('0'+m):m)+'-'+(d<10?('0'+d):d)+'T23:59:59.000Z';
        Attendance.findOne({month: m, year: year, userId: req.body.userId, date: {
            $gte:  y,
            $lt:  t
        }}).populate('user').then(function(record) {
            if(req.body.type == 'approve') {
                var toUser = record.user;
                record.isPaid = true;
                record.isApproved = true;
                record.save(function(err, rs) {
                    if(err) return res.status(500).send({
                        success: false,
                        message: 'error',
                        data: err
                    });
                    //Create Leave If not applied
                    if(rs.leaveType != 'W') {
                        var aLeaves = {
                            leaveDate: dt,
                            leaveType: rs.leaveType,
                            value: (rs.leaveType=='FD'?1:(rs.leaveType=='HD'?0.5:0.25)),
                            status: 1
                        };
                        //Send email to user for approving leave
                        var options = GlobalConfig.emailOptions.approveLeave;
                        var to = toUser;
                        var template = options.template;
                        var opts = {
                            subject:  options.subject,
                            from: req.auth.credentials,
                            body: {
                                leaveDate: new moment(req.body.date).format('L'),
                                leaveType: req.body.leaveType=='SL'?'Short Leave':(req.body.leaveType=='HD'?'Half Day': 'Full Day'),
                                reason: req.body.reason
                            }
                        };
                        MailHelper.sendEmailBySendgrid(to, opts, template);
                        Leave.findOne({user: req.body.user, year: year, 'applied.leaveDate': {$gte:  y, $lt:  t}}, function(err, aleave) {
                            if(aleave) {
                                var k = 0;
                                var f = false;
                                for(var i=0; i<aleave.applied.length; i++) {
                                    var m1 = aleave.applied[i].leaveDate.getMonth()+1;
                                    var d1 = aleave.applied[i].leaveDate.getDate();
                                    var l = aleave.applied[i].leaveDate.getFullYear()+'-'+(m1<10?('0'+m1):m1)+'-'+(d1<10?('0'+d1):d1);
                                    if(l == y.split('T')[0]) {
                                        k = i;
                                        f = true;
                                    }
                                }
                                //update existing applied leave
                                if(f) {
                                    aleave.applied[k].leaveType = aLeaves.leaveType;
                                    aleave.applied[k].value = aLeaves.value;
                                    aleave.applied[k].status = aLeaves.status;
                                    aleave.save(function(err, results) {
                                    });
                                }
                            } else {
                                Leave.update({ user: req.body.user, year: year }, { $push: { applied: { $each: [ aLeaves ]}}}, function(err, results) {
                                });
                            }
                        });
                    }
                    res.status(200).send({
                        success: true,
                        message: 'success',
                        data: rs
                    });
                });
            } else if (req.body.type == 'ignore') {
                record.arrivalTime = '10:00';
                record.leavingTime = '18:10';
                record.leaveType = 'W';
                record.isPaid = true;
                record.isApproved = true;
                record.save(function(err, rs) {
                    if(err) return res.status(500).send({
                        success: false,
                        message: 'error',
                        data: err
                    });
                    res.status(200).send({
                        success: true,
                        message: 'success',
                        data: rs
                    });
                });
            } else {
                res.status(200).send({
                    success: true,
                    message: 'success',
                    data: []
                });
            }
        });
    },

    markAttendanceStatus: function(req, res) {
        var a = req.body.date.split('T')[0];
        var dt = new Date(a);
        var year = dt.getFullYear();
        var m = (dt.getMonth()+1);
        var d = dt.getDate();
        var y = year+'-'+(m<10?('0'+m):m)+'-'+(d<10?('0'+d):d)+'T00:00:00.000Z';
        var t = year+'-'+(m<10?('0'+m):m)+'-'+(d<10?('0'+d):d)+'T23:59:59.000Z';
        Attendance.findOne({month: m, year: year, userId: req.body.userId, date: {
            $gte:  y,
            $lt:  t
        }}).populate('user').then(function(record) {
            if (req.body.status == 'SL') {
                // record.arrivalTime = '10:00';
                // record.leavingTime = '17:00';
                record.leaveType = 'SL';
                record.isPaid = false;
                record.isApproved = false;
                record.save(function(err, rs) {
                    if(err) return res.status(500).send({
                        success: false,
                        message: 'error',
                        data: err
                    });
                    return res.status(200).send({
                        success: true,
                        message: 'success',
                        data: rs
                    });
                });
            } else if (req.body.status == 'HD') {
                // record.arrivalTime = '10:00';
                // record.leavingTime = '15:00';
                record.leaveType = 'HD';
                record.isPaid = false;
                record.isApproved = false;
                record.save(function(err, rs) {
                    if(err) return res.status(500).send({
                        success: false,
                        message: 'error',
                        data: err
                    });
                    return res.status(200).send({
                        success: true,
                        message: 'success',
                        data: rs
                    });
                });
            } else if (req.body.status == 'FD') {
                // record.arrivalTime = '10:00';
                // record.leavingTime = '15:00';
                record.leaveType = 'FD';
                record.isPaid = false;
                record.isApproved = false;
                record.save(function(err, rs) {
                    if(err) return res.status(500).send({
                        success: false,
                        message: 'error',
                        data: err
                    });
                    return res.status(200).send({
                        success: true,
                        message: 'success',
                        data: rs
                    });
                });
            } else if (req.body.status == 'L') {
                record.arrivalTime = '00:00';
                record.leavingTime = '00:00';
                record.leaveType = 'W';
                record.isPaid = false;
                record.isApproved = false;
                record.save(function(err, rs) {
                    if(err) return res.status(500).send({
                        success: false,
                        message: 'error',
                        data: err
                    });
                    return res.status(200).send({
                        success: true,
                        message: 'success',
                        data: rs
                    });
                });
            } else {
                res.status(200).send({
                    success: true,
                    message: 'success',
                    data: []
                });
            }
        });
    }
};
