/*******************************************************************************
 * Leave Controller
 ******************************************************************************/
'use strict';
const mongoose = require('mongoose');
const Leave = mongoose.model('Leave');
const User = mongoose.model('User');
const EmployeeSalarySlip = mongoose.model('EmployeeSalarySlip');
const Q = require('q');
const moment = require('moment');
const Config = require('../config/config');
const GlobalConfig = require('../config/gconfig');
const CommonHelper = require('../helpers/common');
const MailHelper = require('../helpers/mail');

module.exports = {

    createLeaves: async function (req, res) {
        var year = req.query.year;
        if( !year ) return res.send({"error": "year is missing"});
        var users = await User.find({userId: { $ne: 0} }).exec();
        var ids = [];
        var errs = [];
        for(var i=0; i<users.length; i++) {
            await Leave.findOne({ user: users[i]._id, year: year }, function(err, item) {
                if( !item ) {
                    ids.push(users[i].userId);
                    var l = new Leave({
                        user: users[i]._id,
                        year: year
                    });
                    l.save(function(err, leave) {
                        if(err) {
                            errs.push(err);
                        }
                    })
                }
            });
        }
        return res.status(200).send({"message": "User leave object exist already for "+ ids });
    },

    earnedLeave: async function(req, res) {
        var month = req.query.month;
        var year = req.query.year;
        if( !month ) return res.send({"error": "Month is missing"});
        if( !year ) return res.send({"error": "year is missing"});
        var mTitle = GlobalConfig.monthsName[month-1];
        if( !mTitle ) return res.send({"error": "Month is invalid"});

        var users = await User.find({userId: { $ne: 0} }).exec();
        var ids = [];
        for(var i=0; i<users.length; i++) {
            ids.push(users[i].userId);
            await Leave.update({ user: users[i]._id, year: year, 'earned.month': { $ne: month } }, { $addToSet: { earned: { $each: [ { month: month, title: mTitle } ] } } }, function(err, results) {
                console.log(err, results);
            });
        }
        return res.status(200).send({"message": "Earned leave object created for All "+ ids });
    },

    getLeaves: function (req, res) {
        var query = {};
        var date = new Date();
        var currentYear = date.getFullYear();
        var currentMonth = date.getMonth()+1;
        if (!query.$and) {
            query.$and = [];
        }
        if(req.query.year) {
            query.$and.push({ year:  req.query.year});
        } else {
            query.$and.push({ year:  currentYear});
        }
        query.$and.push({ user: req.auth.credentials.id });
        Q.all([
            Leave.findOne(query).exec()
        ]).then(function (leaves) {
            var results = leaves[0];
            // if(results) {
            //     var earned = results.earned.length*1.5;
            //     var comsumed = 1;
            //     for(var i=0; i<results.consumed.length; i++) {
            //         comsumed = comsumed + results.consumed[i].value;
            //     }
            //     var ep = results.previous + earned;
            //     var final = ep + consumed;
            //     console.log("final ", final);
            // }
            var fRes = {
                success: true,
                message: 'success',
                data: results
            };
            res.status(200).send(fRes);
        });
    },

    applyLeave: function (req, res) {
        var year = req.body.year;
        var aLeaves = {
            leaveDate: req.body.date,
            leaveType: req.body.leaveType,
            reason: req.body.reason,
            value: (req.body.leaveType=='SL'?0.25:(req.body.leaveType=='HD'?0.5:1))
        }
        Leave.update({ user: req.auth.credentials.id, year: year }, { $push: { applied: { $each: [ aLeaves ]}}}, function(err, results) {
            if(err) {
                return res.status(500).send({
                    success: false,
                    message: 'Data not found',
                    error: err
                });
            }
            //Send email to Reporting Manager
            var options = GlobalConfig.emailOptions.applyForLeave;
            var to = GlobalConfig.reportingManager;
            var template = options.template;
            var opts = {
                subject:  req.auth.credentials.fullName + options.subject,
                from: req.auth.credentials,
                body: {
                    leaveDate: new moment(req.body.date).format('L'),
                    leaveType: req.body.leaveType=='SL'?'Short Leave':(req.body.leaveType=='HD'?'Half Day': 'Full Day'),
                    reason: req.body.reason
                }
            };
            MailHelper.sendEmailBySendgrid(to, opts, template);
            res.status(200).send({
                success: true,
                message: 'success',
                data: results
            });
        });
    },

    removeLeave: function(req, res) {
        var date = new Date();
        var year = date.getFullYear();
        Leave.update({user: req.auth.credentials.id, year: year }, { $pull: { applied: { _id: req.params.id, status: { $ne: 1 } } } }).then((leave) => {
            if (leave.nModified) {
                res.status(200).send({
                    success: true,
                    message: 'You leave has been deleted successfully',
                    data: leave
                });
            } else {
                res.status(404).send({
                    success: false,
                    message: 'Invalid request, data not found',
                    data: null
                });
            }
        });
    },

    getSalarySlips: function(req, res) {
        var query = {};
        var date = new Date();
        var currentYear = date.getFullYear();;
        if (!query.$and) {
            query.$and = [];
        }
        if(req.query.year) {
            query.$and.push({ year:  req.query.year});
        } else {
            query.$and.push({ year:  currentYear});
        }
        query.$and.push({ user: req.auth.credentials.id });
        EmployeeSalarySlip.find(query).then(function(salaries) {
            res.status(200).send({
                success: true,
                message: 'Success',
                data: salaries
            });
        });
    }
};
