/*******************************************************************************
 * EmployeeJobController
 ******************************************************************************/
'use strict';
const mongoose = require('mongoose');
const OpeningJob = mongoose.model('OpeningJob');
const EmployeeResume = mongoose.model('EmployeeResume');
const Config = require('../config/config');
const CommonHelper = require('../helpers/common');
const fs = require('fs');
const Q = require('q');

module.exports = {
    getJobsForWeb: function (req, res) {
        var query = {},
            offset = req.query.offset ? req.query.offset : 0,
            limit = req.query.limit ? req.query.limit : 100;
        if (!query.$and) {
            query.$and = [];
        }
        if(req.query.title) {
            var title = req.query.title;
            query.$and.push({ title: { $regex: new RegExp("^" + title.toLowerCase(), "i") } });
        }
        query.$and.push({ 'status': 1 });
        Q.all([
            OpeningJob.count(query).exec(),
            OpeningJob.find(query).sort('-updated_at').exec()
        ]).then(function (jobs) {
            res.status(200).send({
                success: true,
                message: 'success',
                data: jobs[1],
                totalCount: jobs[0]
            });
        });
    },
    getJobs: function (req, res) {
        var query = {},
            offset = req.query.offset ? req.query.offset : 0,
            limit = req.query.limit ? req.query.limit : 100;
        if(req.query.title) {
            query.$and = [];
            var title = req.query.title;
            query.$and.push({ title: { $regex: new RegExp("^" + title.toLowerCase(), "i") } });
        }
        Q.all([
            OpeningJob.count(query).exec(),
            OpeningJob.find(query).sort('-updated_at').exec()
        ]).then(function (jobs) {
            res.status(200).send({
                success: true,
                message: 'success',
                data: jobs[1],
                totalCount: jobs[0]
            });
        });
    },

    getJobDetail: function(req, res) {
        OpeningJob.findOne({_id: req.params.id}).then((job) => {
            if (job) {
                res.status(200).send({
                    success: true,
                    message: 'success',
                    data: job
                });
            } else {
                res.status(404).send({
                    success: false,
                    message: 'Job not found',
                    data: null
                });
            }
        });
    },

    addJob: function(req, res) {
        var job = new OpeningJob(req.body);
        job.save(function (err, job) {
            if (!err) {
                res.status(200).send({
                    success: true,
                    message: 'Job created successfully',
                    data: job
                });
            } else {
                res.status(401).send({
                    success: false,
                    message: reformatErrors(err)
                });
            }
        });
    },

    UpdateJob: function(req, res) {
        OpeningJob.findOne({_id: req.params.id}, function (err, job) {
            if (!err) {
                job.title = req.body.title;
                job.openings = req.body.openings;
                job.experience = req.body.experience;
                job.desciption = req.body.desciption;
                job.language = req.body.language;
                job.status = req.body.status;
                job.save(function (err, job) {
                    res.status(200).send({
                        success: true,
                        message: 'Job updated successfully',
                        data: job
                    });
                });
            } else {
                res.status(404).send({
                    success: false,
                    message: 'Data not found',
                    data: null
                });
            }
        });
    },

    deleteJob: function(req, res) {
        OpeningJob.findOneAndRemove({_id: req.params.id}).then((job) => {
            if (job) {
                res.status(200).send({
                    success: true,
                    message: 'Job removed successfully',
                    data: []
                });
            } else {
                res.status(404).send({
                    success: false,
                    message: 'No data found',
                    data: null
                });
            }
        });
    },

    applyForJob: function(req, res) {
        function validateRequest(body, file) {
            var s = {
                status: true,
                message: ''
            };
            if(!body.name) {
                s.status = false;
                s.message = 'Name is required';
                return s;
            }
            if(!body.email) {
                s.status = false;
                s.message = 'Email address is required';
                return s;
            }
            if(!body.mobile) {
                s.status = false;
                s.message = 'Mobile number is required';
                return s;
            }
            if(!body.message) {
                s.status = false;
                s.message = 'You message is required';
                return s;
            }
            if(!body.language) {
                s.status = false;
                s.message = 'Language key is missing or empty';
                return s;
            }
            if(!body.appliedFor) {
                s.status = false;
                s.message = 'AppliedFor key is missing or empty';
                return s;
            }
            if(!file) {
                s.status = false;
                s.message = 'You resume is required please attach it';
                return s;
            }
            if(file.fieldname != 'resume') {
                s.status = false;
                s.message = 'You resume is required please attach it';
                return s;
            }
            var fileType = CommonHelper.getFileExtension(file.originalname);
            if(fileType != 'pdf') {
                s.status = false;
                s.message = 'You resume must be in PDF format only';
                return s;
            }
            return s;

        }
        var s = validateRequest(req.body, req.file);
        if( !s.status ) {
            return res.status(401).send({
                success: false,
                message: s.message
            });
        }
        var file = req.file;
        var fileType = CommonHelper.getFileExtension(file.originalname);
        var fileName = req.body.name.toLowerCase()+'-' + Date.now();
        CommonHelper.uploadTOS3(file.path, (fileName+'.'+fileType), function (err, uploadedResume) {
            fs.unlink(file.path, function(err){});
            var resume = new EmployeeResume(req.body);
            resume.resume = uploadedResume;
            resume.save(function (err, resume) {
                if (!err) {
                    res.status(200).send({
                        success: true,
                        message: 'You appplication has been sumitted successfully. We will get back to you soon',
                        data: resume
                    });
                } else {
                    res.status(401).send({
                        success: false,
                        message: reformatErrors(err)
                    });
                }
            });
        });
    },

    getResumes: function (req, res) {
        var query = {},
            offset = req.query.offset ? req.query.offset : 0,
            limit = req.query.limit ? req.query.limit : 50;
        if(req.query.title) {
            query.$and = [];
            var title = req.query.title;
            query.$and.push({ title: { $regex: new RegExp("^" + title.toLowerCase(), "i") } });
        }
        Q.all([
            EmployeeResume.count(query).exec(),
            EmployeeResume.find(query).sort('-updated_at').populate('appliedFor', 'title').exec()
        ]).then(function (resumes) {
            res.status(200).send({
                success: true,
                message: 'success',
                data: resumes[1],
                totalCount: resumes[0]
            });
        });
    },
};
