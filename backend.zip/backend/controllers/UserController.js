/*******************************************************************************
 * User Controller
 ******************************************************************************/
'use strict';
const mongoose = require('mongoose');
const User = mongoose.model('User');
const Attendance = mongoose.model('Attendance');
const Holidays = mongoose.model('Holidays');
const Leave = mongoose.model('Leave');
const Section = mongoose.model('Section');
const _ = require('underscore-node');
const Config = require('../config/config');
const GlobalConfig = require('../config/gconfig');
const Jwt = require('jsonwebtoken');
const MailHelper = require('../helpers/mail');
const Q = require('q');
const CommonHelper = require('../helpers/common');
const reformatErrors = require('../lib/mongoose-errors');
const UserTransformer = require('../transformers/user');

module.exports = {
    index: function (req, reply) {
        reply({ "message": "Working server" });
    },
    getModuleList: function(req, res) {
        res.status(200).send({
            success: true,
            message: 'success',
            data: Config.deaultSuperAdmin.modulesAndpermissions
        });
    },
    addSection: function(req, res) {
        var section = new Section(req.body);
        section.save(function (err, section) {
            if (!err) {
                res.status(200).send({
                    success: true,
                    message: 'success',
                    data: section
                });
            } else {
                res.status(404).send({
                    success: false,
                    message: 'Data not found',
                    error: reformatErrors(err)
                });
            }
        });
    },

    updateSection: function(req, res) {
        Section.findOne({_id: req.params.id}, function (err, section) {
            if (!err) {
                section.name = req.body.name;
                section.description = req.body.description;
                section.save(function (err, section) {
                    res.status(200).send({
                        success: true,
                        message: 'success',
                        data: section
                    });
                });
            } else {
                res.status(404).send({
                    success: false,
                    message: 'Data not found',
                    data: null
                });
            }
        });
    },

    getSections: function(req, res) {
        Section.find({}, function (err, sections) {
            if (!err) {
                res.status(200).send({
                    success: true,
                    message: 'success',
                    data: sections
                });
            } else {
                res.status(404).send({
                    success: false,
                    message: 'Data not found',
                    data: null
                });
            }
        });
    },

    getSectionDetail: function(req, res) {
        Section.findOne({_id: req.params.id}).then((section) => {
            res.status(200).send({
                success: true,
                message: 'success',
                data: section
            });
        });
    },

    getUserListForFilter: function(req, res) {
        var query = {}
        if (!query.$and) {
            query.$and = [];
        }
        if(req.auth.credentials.adminType == 1) {
            query.$and.push({ _id: { $ne: req.auth.credentials.id } });
        } else {
            query.$and.push({ _id: req.auth.credentials.id });
        }
        //Execute the query at a later time
        Q.all([
            User.count(query).exec(),
            User.find(query).sort('fullName').exec()
        ]).then(function (users) {
            res.status(200).send({
                success: true,
                message: 'success',
                data: users[1],
                totalCount: users[0]
            });
        });
    },

    getUserList: function(req, res) {
        var query = {},
            offset = req.query.offset ? req.query.offset : 0,
            limit = req.query.limit ? req.query.limit : 10;
        if (!query.$and) {
            query.$and = [];
        }
        if(req.query.name) {
            var name = req.query.name;
            //query.$and.push({'$or': [{ fullName: { $regex: new RegExp("^" + name.toLowerCase(), "i") }}, { userId: name} ] });
            query.$and.push({ fullName: { $regex: new RegExp("^" + name.toLowerCase(), "i") } });
        }
        query.$and.push({ _id: { $ne: req.auth.credentials.id } });
        //Execute the query at a later time
        Q.all([
            User.count(query).exec(),
            User.find(query).sort('fullName').skip(parseInt(offset)).limit(parseInt(limit)).exec()
        ]).then(function (users) {
            res.status(200).send({
                success: true,
                message: 'success',
                data: users[1],
                totalCount: users[0]
            });
        });
    },

    getUserProfile: function(req, res) {
        User.findOne({ $and: [{ _id: req.params.id }, { userType: 2 }] }, function (err, user) {
            if (err || !user) {
                return res.status(400).send({
                    success: false,
                    message: 'Request not allowed',
                    data: null
                });
            }
            res.status(200).send({
                success: true,
                message: 'success',
                data: user
            });
        });
    },

    updateUserBankDetail: function(req, res) {
        User.findOne({ _id: req.params.id }, function(err, user) {
            if(!user) {
                return res.status(404).send({
                    success: true,
                    message: 'record not found',
                    data: user
                });
            }
            if( !user.bankDetails ) {
                user.bankDetails = {}
            }
            user.bankDetails.bankName = req.body.bankName;
            user.bankDetails.accountNumber = req.body.accountNumber;
            user.bankDetails.branch = req.body.branch;
            user.bankDetails.address = req.body.address;
            user.save(function(err, user) {
                if(err) {
                    return res.status(500).send({
                        success: false,
                        message: 'success',
                        data: err
                    });
                }
                res.status(200).send({
                    success: true,
                    message: 'success',
                    data: user
                });
            });
        });
    },

    updateUserSalaryStructure: function(req, res) {
        User.findOne({ _id: req.params.id }, function(err, user) {
            if(!user) {
                return res.status(404).send({
                    success: true,
                    message: 'record not found',
                    data: user
                });
            }
            if(!user.salaryStructure) user.salaryStructure = {};
            user.salaryStructure.basic = req.body.basic;
            user.salaryStructure.hra = req.body.hra;
            user.salaryStructure.lta = req.body.lta;
            user.salaryStructure.travelAllowance = req.body.travelAllowance;
            user.salaryStructure.specialAllowance = req.body.specialAllowance;
            user.salaryStructure.medicalReimbursement = req.body.medicalReimbursement;
            user.salaryStructure.foodReimbursement = req.body.foodReimbursement;
            user.salaryStructure.bookAndPeriodicals = req.body.bookAndPeriodicals;
            user.salaryStructure.studyChagres = req.body.studyChagres;
            user.salaryStructure.uniformAllowance = req.body.uniformAllowance;
            user.salaryStructure.mobileAndInternet = req.body.mobileAndInternet;
            user.save(function(err, rs) {
                if(err) {
                    return res.status(500).send({
                        success: false,
                        message: 'success',
                        data: err
                    });
                }
                res.status(200).send({
                    success: true,
                    message: 'success',
                    data: rs
                });
            });
        });
    },

    createUser: function (req, res) {
        if(req.auth.credentials.adminType != 1) {
            return res.status(400).send({
                success: false,
                message: 'Request not allowed',
                data: null
            });
        }
        User.findOne({ email: req.body.email }, function (err, usr) {
            if(usr) {
                return res.status(400).send({
                    success: false,
                    message: '<strong>'+req.body.email+'</strong> '+' is already used for another user',
                    data: err
                });
            }
            var empCode = 'HLK-0';
            if(req.body.userId) {
                empCode = 'HLK-'+req.body.userId;
            }
            const user = {
                empCode: empCode,
                userId: req.body.userId?req.body.userId:0,
                fullName: req.body.fullName,
                email: req.body.email,
                password: CommonHelper.encrypt(req.body.password),
                mobile: req.body.mobile?req.body.mobile:'',
                gender: req.body.gender?req.body.gender:'',
                dob: req.body.dob,
                joiningDate: req.body.joiningDate,
                salary: req.body.salary,
                joiningPosition: req.body.position,
                position: req.body.position,
                pencardNumber: req.body.pencardNumber,
                adharcardNumber: req.body.adharcardNumber,
                fatherName: req.body.fatherName,
                fatherContactNumber: req.body.fatherContactNumber,
                currentAddress: req.body.currentAddress,
                permanentAddress: req.body.permanentAddress,
                PFNumber: req.body.PFNumber,
                PFUANNumber: req.body.PFUANNumber,
                ESIAccNumber: req.body.ESIAccNumber,
                userType: 2,
                adminType: 2,
                modulesAndpermissions: req.body.modules
            };
            User.create(user, function (err, user) {
                if (err) {
                    return res.status(400).send({
                        success: false,
                        message: 'Something went wrong',
                        error: reformatErrors(err)
                    });
                }
                res.status(200).send({
                    success: true,
                    message: 'User created successfully',
                    data: []
                });
            });
        });
    },

    login: function (req, res) {
        User.findOne({ email: req.body.email }, function (err, user) {
            if (!err) {
                if (user === null) {
                    return res.status(401).send({
                        success: false,
                        message: 'Invalid Email or Password',
                        data: null
                    });
                }
                if (user.isAccountVerified === false) {
                    return res.status(401).send({
                        success: false,
                        message: 'Invalid Email or Password',
                        data: null
                    });
                }

                if (req.body.password === CommonHelper.decrypt(user.password)) {
                    var permissions = {};
                    var modules = [];
                    for(var i=0; i<user.modulesAndpermissions.length; i++) {
                        if(user.modulesAndpermissions[i].selected) {
                            modules.push(user.modulesAndpermissions[i].key);
                        }
                        permissions[user.modulesAndpermissions[i].key] = {
                            selected: user.modulesAndpermissions[i].selected,
                            name: user.modulesAndpermissions[i].name,
                            key: user.modulesAndpermissions[i].key,
                            permissions: {
                                U: user.modulesAndpermissions[i].permissions.U,
                                W: user.modulesAndpermissions[i].permissions.W,
                                R: user.modulesAndpermissions[i].permissions.R,
                                D: user.modulesAndpermissions[i].permissions.D
                            }
                        };
                    }
                    var loginData = {
                        id: user._id,
                        email: req.body.email,
                        userId: user.userId,
                        fullName: user.fullName,
                        mobile: user.mobile,
                        userType: user.userType,
                        adminType: user.adminType,
                        access: permissions
                    };
                    var token = Jwt.sign(loginData, Config.key.privateKey);
                    var options = Config.emailOptions.loginConfirm;
                    user = user.toObject();
                    user.modulesAndpermissions = modules;
                    //MailHelper.sendEmailBySendgrid(user, options);
                    res.status(200).send({ 'data': UserTransformer(user), token: token });
                } else {
                    res.status(401).send({
                        success: false,
                        message: 'Invalid Email or Password',
                        data: null
                    });
                }
            } else {
                res.status(401).send({
                    success: false,
                    message: 'Invalid Email or Password',
                    data: null
                });
            }
        });
    },

    createSuperAdmin: function (req, res) {
        req.body.password = CommonHelper.encrypt(req.body.password);
        var user = new User(req.body);
        user.save(function (err, user) {
            if (!err) {
                user.save(function (err, user) {
                    if (err || !user) return res.status(404).send('Request not found');
                });
                res.status(200).send(user);
            } else {
                res.status(401).send('Request is not allowed');
            }
        });
    },

    createDefaultSuperAdmin: function (req, res) {
        var data = [];
        var nuser = {
            email: Config.deaultSuperAdmin.email,
            password: Config.deaultSuperAdmin.password,
            fullName: Config.deaultSuperAdmin.fullName,
            userType: Config.deaultSuperAdmin.userType,
            adminType: Config.deaultSuperAdmin.adminType,
            empCode: Config.deaultSuperAdmin.empCode,
        }
        User.findOne({ email: nuser.email }, function (err, usr) {
            if( !usr ) {
                for(var i=0; i<Config.deaultSuperAdmin.modulesAndpermissions.length; i++) {
                    data.push({
                        key: Config.deaultSuperAdmin.modulesAndpermissions[i].key,
                        name: Config.deaultSuperAdmin.modulesAndpermissions[i].name,
                        selected: true,
                        permissions: {
                            'R': true,
                            'W': true,
                            'D': true,
                            'U': true
                        }
                    });
                }
                nuser.modulesAndpermissions = data;
                var user = new User(nuser);
                user.password = CommonHelper.encrypt(nuser.password);
                user.save(function (err, user) {
                    if (!err) {
                        console.log("Supper Admin created successfully");
                    }
                });
            } else {
                for(var i=0; i<Config.deaultSuperAdmin.modulesAndpermissions.length; i++) {
                    data.push({
                        key: Config.deaultSuperAdmin.modulesAndpermissions[i].key,
                        name: Config.deaultSuperAdmin.modulesAndpermissions[i].name,
                        selected: true,
                        permissions: {
                            'R': true,
                            'W': true,
                            'D': true,
                            'U': true
                        }
                    });
                }
                usr.empCode = nuser.empCode;
                usr.modulesAndpermissions = data;
                usr.save(function (err, user) {
                    if (!err) {
                        console.log("Supper Admin updated successfully");
                    }
                });
            }
        });
    },

    getProfile: function (req, res) {
        User.findOne({ _id: req.auth.credentials.id }, function (err, user) {
            if (user) {
                res.status(200).send({
                    success: true,
                    message: 'success',
                    data: user
                });
            } else {
                res.status(404).send({
                    success: false,
                    message: 'Data not found',
                    data: null
                });
            }
        });
    },

    updateProfile: function (req, res) {
        User.findOne({ _id: req.auth.credentials.id }, function (err, user) {
            if (user) {
                user.fullName = req.body.fullName;
                user.mobile = req.body.mobile?req.body.mobile:'';
                user.gender = req.body.gender?req.body.gender:'';
                user.dob = req.body.dob;
                user.fatherName = req.body.fatherName;
                user.fatherContactNumber = req.body.fatherContactNumber;
                if(req.body.pencardNumber) user.pencardNumber = req.body.pencardNumber;
                if(req.body.adharcardNumber) user.adharcardNumber = req.body.adharcardNumber;
                if(req.body.PFNumber) user.PFNumber = req.body.PFNumber;
                if(req.body.PFUANNumber) user.PFUANNumber = req.body.PFUANNumber;
                user.save(function (err, user) {
                    res.status(200).send({
                        success: true,
                        message: 'Your profile has been updated successfully',
                        data: user
                    });
                });
            } else {
                res.status(404).send({
                    success: false,
                    message: 'Data not found',
                    data: null
                });
            }
        });
    },

    updateUser: function (req, res) {
        if(req.auth.credentials.adminType != 1) {
            return res.status(400).send({
                success: false,
                message: 'Request not allowed',
                data: null
            });
        }
        User.findOne({ _id: req.params.id }, function (err, user) {
            if (!user) {
                return res.status(400).send({
                    success: false,
                    message: 'User not found',
                    data: null
                });
            }
            user.fullName = req.body.fullName;
            user.email = req.body.email;
            user.mobile = req.body.mobile?req.body.mobile:'';
            user.gender = req.body.gender?req.body.gender:'';
            user.dob = req.body.dob;
            user.joiningDate = req.body.joiningDate;
            user.salary = req.body.salary;
            user.joiningPosition = req.body.position;
            user.position = req.body.position;
            user.pencardNumber = req.body.pencardNumber;
            user.adharcardNumber = req.body.adharcardNumber;
            user.fatherName = req.body.fatherName;
            user.fatherContactNumber = req.body.fatherContactNumber;
            user.PFNumber = req.body.PFNumber;
            user.PFUANNumber = req.body.PFUANNumber;
            user.ESIAccNumber = req.body.ESIAccNumber;
            user.currentAddress = req.body.currentAddress;
            user.permanentAddress = req.body.permanentAddress;
            user.modulesAndpermissions = req.body.modulesAndpermissions?req.body.modulesAndpermissions:user.modulesAndpermissions;
            user.save(function (err, user) {
                res.status(200).send({
                    success: true,
                    message: 'User & module access updated successfully',
                    data: user
                });
            });
        });
    },

    changePassword: function (req, res) {
        var oldPassword = req.body.oldPassword;
        var newPassword = req.body.newPassword;
        var confirmPassword = req.body.confirmPassword;
        if (oldPassword === newPassword) {
            return res.status(400).send({
                success: false,
                message: 'Old and New password are same',
                data: null
            });
        }
        if (newPassword !== confirmPassword) {
            return res.status(400).send({
                success: false,
                message: 'New and Confirm password do not match',
                data: null
            });
        }
        User.findOne({ _id: req.auth.credentials.id }, function (err, user) {
            if (user) {
                if (user.password !== CommonHelper.encrypt(oldPassword)) {
                    return res.status(400).send({
                        success: false,
                        message: 'Your old password is incorrect',
                        data: null
                    });
                }
                user.password = CommonHelper.encrypt(newPassword);
                user.save(function (err, user) {
                    return res.status(200).send({
                        success: true,
                        message: 'The password has been updated successfully',
                        data: null
                    });
                });
            } else {
                return res.status(500).send({
                    success: false,
                    message: 'Something went wrong',
                    data: null
                });
            }
        });
    },

    getEmployeeAttendances: function (req, res) {
        function getDaysInMonth(month, year) {
            var totalDays = new Date(year, month, 0).getDate();
            var wDays = [];
            for(var i=1; i<=totalDays; i++) {
                var dt = new Date(year+'-'+(month<10?('0'+month):month)+'-'+(i<10?('0'+i):i));
                var d = dt.getDay();
                if(d>0 && d<6) {
                    wDays.push(year+'-'+(month<10?('0'+month):month)+'-'+(i<10?('0'+i):i)+'T00:00:00.000Z');
                }
            }
            return {
                tds: totalDays,
                wtds: wDays
            };
        }

        var query = {};
        var date = new Date();
        var year = req.query.year?req.query.year:(date.getFullYear());
        var month = req.query.month?req.query.month:(date.getMonth()+1);
        var holidays = [];
        var td = getDaysInMonth(month, year);
        var otherInfo = {
            totalDays: td.tds,
            workingDays: td.wtds.length,
            holidays: 0,
            leaves: 0,
            paidLeaves: 0,
            unpaidLeave: 0
        };

        if (!query.$and) {
            query.$and = [];
        }
        query.$and.push({ month:  month});
        query.$and.push({ year:  year});
        query.$and.push({ user: req.params.id });

        Attendance.find(query).sort('-date').then(function (attendances) {
            for(var l=0; l<attendances.length; l++) {
                if(attendances[l].leaveType == 'FD') {
                    otherInfo.leaves = otherInfo.leaves + 1;
                    if(attendances[l].isApproved && attendances[l].isPaid) {
                        otherInfo.paidLeaves = otherInfo.paidLeaves + 1;
                    }
                    if( !( attendances[l].isApproved && attendances[l].isPaid) ) {
                        otherInfo.unpaidLeave = otherInfo.unpaidLeave + 1;
                    }
                }
                if(attendances[l].leaveType == 'HD') {
                    otherInfo.leaves = otherInfo.leaves + 0.5;
                    if(attendances[l].isApproved && attendances[l].isPaid) {
                        otherInfo.paidLeaves = otherInfo.paidLeaves + 0.5;
                    }
                    if( !( attendances[l].isApproved && attendances[l].isPaid) ) {
                        otherInfo.unpaidLeave = otherInfo.unpaidLeave + 0.5;
                    }
                }
                if(attendances[l].leaveType == 'SL') {
                    otherInfo.leaves = otherInfo.leaves + 0.25;
                    if(attendances[l].isApproved && attendances[l].isPaid) {
                        otherInfo.paidLeaves = otherInfo.paidLeaves + 0.25;
                    }
                    if( !( attendances[l].isApproved && attendances[l].isPaid) ) {
                        otherInfo.unpaidLeave = otherInfo.unpaidLeave + 0.25;
                    }
                }
            }
            Holidays.findOne({ year: year }, function (err, hdays) {
                if(hdays && hdays.holidays.length) {
                        for(var k=1; k<=hdays.holidays.length; k++) {
                            var dmk = hdays.holidays[k-1].date.split('T')[0].split('-');
                            var mk = month<10?('0'+month):month;
                            var mk1 = dmk[1];
                            if((mk == mk1) && (hdays.holidays[k-1].type == 'holiday')) {
                                holidays.push(hdays.holidays[k]);
                            }
                        }
                    otherInfo.holidays = holidays.length;
                }
                var fRes = {
                    success: true,
                    message: 'success',
                    data: attendances,
                    other: otherInfo,
                    totalCount: attendances.length
                };
                res.status(200).send(fRes);
            });
        });
    },

    getEmployeeLeaves: function (req, res) {
        var query = {};
        var date = new Date();
        var currentYear = date.getFullYear();
        var currentMonth = date.getMonth()+1;
        if (!query.$and) {
            query.$and = [];
        }
        query.$and.push({ year:  currentYear});
        query.$and.push({ user: req.params.id });
        Leave.findOne(query).then(function(leaves) {
            var mrds = [];
            for(var i=currentMonth; i>=1; i--) {
                var consumed = 0;
                for(var k=0; k<leaves.consumed.length; k++) {
                    var mm = leaves.consumed[k].date.getMonth()+1;
                    if(mm == i) {
                        consumed += leaves.consumed[k].value;
                    }
                }
                mrds.push({
                    month: i,
                    monthName: GlobalConfig.monthsName[i-1],
                    earned: 1.5,
                    consumed: consumed
                });
            }
            var a = 0, c=0;
            for(var j=0; j<mrds.length; j++) {
                a += mrds[j].earned;
                c += mrds[j].consumed;
            }
            var result = {
                previous: leaves.previous,
                remaining: ( (leaves.previous+a)-c ),
                months: mrds
            };
            var fRes = {
                success: true,
                message: 'success',
                data: result
            };
            res.status(200).send(fRes);
        });
    }
};
