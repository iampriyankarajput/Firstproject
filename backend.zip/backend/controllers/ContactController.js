/*******************************************************************************
 * Contact Controller
 ******************************************************************************/
'use strict';
const mongoose = require('mongoose');
const Contact = mongoose.model('Contact');
const WebProspect = mongoose.model('WebProspect');
const Config = require('../config/config');
const GlobalConfig = require('../config/gconfig');
const Q = require('q');
const moment = require('moment');
const reformatErrors = require('../lib/mongoose-errors');
const CommonHelper = require('../helpers/common');
const MailHelper = require('../helpers/mail');

 function parseUrlToSave(url) {
    url = url.replace('http://', '');
    url = url.replace('https://', '');
    url = url.replace('HTTP://', '');
    url = url.replace('HTTPS://', '');
    url = url.replace('www.', '');
    url = url.replace('www', '');
    url = url.replace('WWW.', '');
    url = url.replace('WWW', '');
    return 'http://www.'+url;
};

module.exports = {

    getContacts: function (req, res) {
        var query = {};
        if (!query.$and) {
            query.$and = [];
        }
        if(req.query.name) {
            var name = req.query.name;
            query.$and.push({'$or': [{ name: { $regex: new RegExp("^" + name.toLowerCase(), "i") }}, { email: { $regex: new RegExp("^" + name.toLowerCase(), "i") }}, { mobile: { $regex: new RegExp("^" + name, "i") }}] });
        }
        if(req.query.type) {
            var type = req.query.type;
            query.$and.push({ contactType: type });
        }
        if(req.query.from) {
            var from = req.query.from;
            query.$and.push({ joinFrom: from });
        }
        if(req.query.language) {
            var language = req.query.language;
            query.$and.push({ language: language });
        }
        if(req.query.created_at) {
            var created_at = req.query.created_at;
            var start = new Date(created_at);
            var y = start.getFullYear();
            var m = start.getMonth()+1;
            var d = start.getDate();
            var dt = y+'-'+(m>9?m:('0'+m))+'-'+(d>9?d:('0'+d));
            var end = moment.utc(dt).endOf('day').toDate();
            query.$and.push({ created_at: {'$gte': start, '$lte': end} });
        }
        if( !query.$and.length ) {
            query = {};
        }
        Q.all([
            Contact.count(query).exec(),
            Contact.find(query).sort('-created_at').exec()
        ]).then(function (contacts) {
            res.status(200).send({
                success: true,
                message: 'success',
                data: contacts[1],
                totalCount: contacts[0]
            });
        });
    },

    addContact: function(req, res) {
        var contact = new Contact(req.body);
        contact.save(function (err, contact) {
            if (!err) {
                res.status(200).send({
                    success: true,
                    message: Config.thankYouMessage['en'],
                    data: []
                });
            } else {
                res.status(401).send({
                    success: false,
                    message: reformatErrors(err)
                });
            }
        });
    },

    getContactDetail: function(req, res) {
        Contact.findOne({_id: req.params.id}).then((contact) => {
            if (contact) {
                res.status(200).send({
                    success: true,
                    message: 'success',
                    data: contact
                });
            } else {
                res.status(404).send({
                    success: false,
                    message: 'No data found',
                    data: null
                });
            }
        });
    },

    removeContact: function(req, res) {
        Contact.findOneAndRemove({_id: req.params.id}).then((contact) => {
            if (contact) {
                res.status(200).send({
                    success: true,
                    message: 'Contact removed successfully',
                    data: []
                });
            } else {
                res.status(404).send({
                    success: false,
                    message: 'No data found',
                    data: null
                });
            }
        });
    },

    getWebContacts: function (req, res) {
        var query = {};
        if (!query.$and) {
            query.$and = [];
        }
        if(req.query.name) {
            var name = req.query.name;
            query.$and.push({'$or': [{ name: { $regex: new RegExp("^" + name.toLowerCase(), "i") }}, { email: { $regex: new RegExp("^" + name.toLowerCase(), "i") }}, { mobile: { $regex: new RegExp("^" + name, "i") }}] });
        }
        if(req.query.category) {
            var category = req.query.category;
            query.$and.push({ category: category });
        }
        if(req.query.from) {
            var from = req.query.from;
            query.$and.push({ joinFrom: from });
        }
        if(req.query.language) {
            var language = req.query.language;
            query.$and.push({ language: language });
        }
        if(req.query.created_at) {
            var created_at = req.query.created_at;
            var start = new Date(created_at);
            var y = start.getFullYear();
            var m = start.getMonth()+1;
            var d = start.getDate();
            var dt = y+'-'+(m>9?m:('0'+m))+'-'+(d>9?d:('0'+d));
            var end = moment.utc(dt).endOf('day').toDate();
            query.$and.push({ created_at: {'$gte': start, '$lte': end} });
        }
        if( !query.$and.length ) {
            query = {};
        }
        Q.all([
            WebProspect.count(query).exec(),
            WebProspect.find(query).sort('-created_at').exec()
        ]).then(function (contacts) {
            for(var i=0; i<contacts[1].length; i++) {
                contacts[1][i].language = Config.languagesText[contacts[1][i].language];
            }
            res.status(200).send({
                success: true,
                message: 'success',
                data: contacts[1],
                totalCount: contacts[0]
            });
        });
    },

    addWebContact: function(req, res) {
        if(req.body.websiteUrl) {
            req.body.websiteUrl = parseUrlToSave(req.body.websiteUrl);
        }
        var contact = new WebProspect(req.body);
        contact.save(function (err, contact) {
            if (!err) {
                //Send email to Reporting Manager
                var options = GlobalConfig.emailOptions.contactNotification;
                var to = {
                    email: 'a.scipio@huulke.com',
                    fullName: 'Angelo Scipio'
                };
                var template = options.template;
                var opts = {
                    subject:  req.body.name+' has sent you message on Huulke',
                    from: {
                        fullName: req.body.name,
                        email: req.body.email,
                        mobile: req.body.mobile,
                        message: req.body.message
                    },
                    body: {
                        fullName: req.body.name,
                        email: req.body.email,
                        mobile: req.body.mobile,
                        message: req.body.message
                    }
                };
                var to1 = {
                    email: 'm.ligari@huulke.com',
                    fullName: 'Matteo Ligari'
                };
                var to2 = {
                    email: 'tatiana@huulke.com',
                    fullName: 'Tatiana Nugaev'
                };
                MailHelper.sendEmailBySendgrid(to2, opts, template);
                MailHelper.sendEmailBySendgrid(to1, opts, template);
                MailHelper.sendEmailBySendgrid(to, opts, template);
                res.status(200).send({
                    success: true,
                    message: Config.thankYouMessage['en'],
                    data: contact
                });
            } else {
                res.status(401).send({
                    success: false,
                    message: reformatErrors(err)
                });
            }
        });
    },

    addWebContactCallPlan: function(req, res) {
        WebProspect.findOne({_id: req.params.id}).then((contact) => {
            if (contact) {
                contact.callPlan = req.body;
                contact.save(function (err, contact) {
                    if (!err) {
                        res.status(200).send({
                            success: true,
                            message: Config.thankYouMessage['en'],
                            data: []
                        });
                    } else {
                        res.status(401).send({
                            success: false,
                            message: reformatErrors(err)
                        });
                    }
                });
            } else {
                res.status(404).send({
                    success: false,
                    message: 'No data found',
                    data: null
                });
            }
        });
    },

    getWebContactDetail: function(req, res) {
        WebProspect.findOne({_id: req.params.id}).then((contact) => {
            if (contact) {
                contact.language = Config.languagesText[contact.language];
                res.status(200).send({
                    success: true,
                    message: 'success',
                    data: contact
                });
            } else {
                res.status(404).send({
                    success: false,
                    message: 'No data found',
                    data: null
                });
            }
        });
    },

    removeWebContact: function(req, res) {
        WebProspect.findOneAndRemove({_id: req.params.id}).then((contact) => {
            if (contact) {
                res.status(200).send({
                    success: true,
                    message: 'Contact removed successfully',
                    data: []
                });
            } else {
                res.status(404).send({
                    success: false,
                    message: 'No data found',
                    data: null
                });
            }
        });
    },

    moveToLead: function(req, res) {
        var category = req.body.category;
        WebProspect.findOneAndUpdate({_id: req.params.id}, {$set: {category: category} }).then((contact) => {
            if (contact) {
                res.status(200).send({
                    success: true,
                    message: 'Category updated successfully',
                    data: []
                });
            } else {
                res.status(404).send({
                    success: false,
                    message: 'No data found',
                    data: null
                });
            }
        });
    }
};
