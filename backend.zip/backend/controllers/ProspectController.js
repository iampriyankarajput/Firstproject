/*******************************************************************************
 * Prospect Controller
 ******************************************************************************/
'use strict';
const mongoose = require('mongoose');
const Prospect = mongoose.model('Prospect');
const Cxo = mongoose.model('Cxo');
const Config = require('../config/config');
const Q = require('q');
const moment = require('moment');
const reformatErrors = require('../lib/mongoose-errors');
const CommonHelper = require('../helpers/common');
const cache = require('memory-cache');
const MemCache = new cache.Cache();
module.exports = {
    index: function (req, reply) {
        reply({ "message": "Working server" });
    },

    addCxos: function(req, res) {
        var cxo = new Cxo(req.body);
        cxo.save(function (err, cxo) {
            if (!err) {
                res.status(200).send({
                    success: true,
                    message: 'success',
                    data: cxo
                });
            } else {
                res.status(404).send({
                    success: false,
                    message: 'Data not found',
                    error: reformatErrors(err)
                });
            }
        });
    },

    updateCxos: function(req, res) {
        Cxo.findOne({_id: req.params.id}, function (err, cxo) {
            if (!err) {
                cxo.name = req.body.name;
                cxo.description = req.body.description;
                cxo.save(function (err, cxo) {
                    res.status(200).send({
                        success: true,
                        message: 'success',
                        data: cxo
                    });
                });
            } else {
                res.status(404).send({
                    success: false,
                    message: 'Data not found',
                    data: null
                });
            }
        });
    },

    getCxos: function(req, res) {
        Cxo.find({}, function (err, cxos) {
            if (!err) {
                res.status(200).send({
                    success: true,
                    message: 'success',
                    data: cxos
                });
            } else {
                res.status(404).send({
                    success: false,
                    message: 'Data not found',
                    data: null
                });
            }
        });
    },

    getCxosDetail: function(req, res) {
        Cxo.findOne({_id: req.params.id}).then((cxo) => {
            res.status(200).send({
                success: true,
                message: 'success',
                data: cxo
            });
        });
    },

    getProspects: function (req, res) {
        var fRes = {
            success: true,
            message: 'success',
            data: [],
            totalCount: 0
        };
        return res.status(200).send(fRes);
        //let key =  '__express__' + req.originalUrl || req.url;
        //let cacheContent = MemCache.get(key);
        // if( cacheContent){
        //     res.status(200).send( cacheContent );
        // } else {
            var query = {},
            offset = req.query.offset ? req.query.offset : 0,
            limit = req.query.limit ? req.query.limit : 10;
            if (!query.$and) {
                query.$and = [];
            }
            if(req.query.name) {
                var name = req.query.name;
                query.$and.push({'$or': [{ name: { $regex: new RegExp("^" + name.toLowerCase(), "i") }}, { email: { $regex: new RegExp("^" + name.toLowerCase(), "i") }}, { websiteUrl: { $regex: new RegExp("^" + name, "i") }}] });
            }
            if(req.query.industry) {
                var industry = req.query.industry;
                query.$and.push({ 'industry.key': industry });
            }
            if(req.query.companySize) {
                var companySize = req.query.companySize;
                query.$and.push({ 'companySize.key': companySize });
            }
            if(req.query.section) {
                var section = req.query.section;
                query.$and.push({ section: section });
            }
            if(req.query.category) {
                var category = req.query.category;
                query.$and.push({ category: category });
            }
            if(req.query.mailSent) {
                var mailSent = (req.query.mailSent==1)?1:0;
                query.$and.push({ mailSent: mailSent });
            }
            if(req.query.creator) {
                var creator = req.query.creator;
                query.$and.push({ creator: creator });
            }
            if(req.query.created_at) {
                var created_at = req.query.created_at;
                var start = new Date(created_at);
                var y = start.getFullYear();
                var m = start.getMonth()+1;
                var d = start.getDate();
                var dt = y+'-'+(m>9?m:('0'+m))+'-'+(d>9?d:('0'+d));
                var end = moment.utc(dt).endOf('day').toDate();
                query.$and.push({ created_at: {'$gte': start, '$lte': end} });
            }
            if(req.auth.credentials.adminType != 1) {
                query.$and.push({ creator: req.auth.credentials.id });
            }
            if( !query.$and.length ) {
                query = {};
            }
            Q.all([
                Prospect.count(query).exec(),
                Prospect.find(query).sort('-created_at').populate('cxo').populate('creator').skip(parseInt(offset)).limit(parseInt(limit)).exec()
            ]).then(function (prospects) {
                var fRes = {
                    success: true,
                    message: 'success',
                    data: prospects[1],
                    totalCount: prospects[0]
                };
                //MemCache.put(key, fRes, 30*1000); //Duration in miliseconds
                res.status(200).send(fRes);
            });
        //}
    },

    importExcelFile: function(req, res) {
        var records = req.body.excelRecords;
        if(records && records.length) {
            for(var i=0; i<records.length; i++) {
                records[i].creator = req.auth.credentials.id;
                records[i].updatedBy = req.auth.credentials.id;
            }
            Prospect.create(records, function(err, rcrds) {
                if(err) {
                    return res.status(500).send({
                        success: false,
                        message: 'Invalid data in excel file please verify it'
                    });
                }
                console.log("Error ", err);
                console.log("Created ", rcrds);
                res.status(200).send({
                    success: true,
                    message: records.length + ' prospects imported successfully',
                    data: []
                });
            });
        } else {
            res.status(404).send({
                success: false,
                message: 'Missing prospects data'
            });
        }
    },

    addProspect: function(req, res) {
        Prospect.findOne({websiteUrl: req.body.websiteUrl}, function(err, pros) {
            if(!pros) {
                var prospect = new Prospect(req.body);
                prospect.creator = req.auth.credentials.id;
                prospect.updatedBy = req.auth.credentials.id;
                prospect.save(function (err, prospect) {
                    if (!err) {
                        res.status(200).send({
                            success: true,
                            message: 'success',
                            data: prospect
                        });
                    } else {
                        res.status(401).send({
                            success: false,
                            message: reformatErrors(err)
                        });
                    }
                });
            } else {
                res.status(401).send({
                    success: false,
                    message: 'Company URL already exists!'
                });
            }
        });
    },

    updateProspect: function(req, res) {
        Prospect.findOne({_id: req.params.id}, function (err, prospect) {
            if (!err) {
                prospect.cxo = req.body.cxo;
                prospect.name = req.body.name;
                prospect.email = req.body.email;
                prospect.mobile = req.body.mobile;
                prospect.industry = req.body.industry;
                prospect.section = req.body.section;
                prospect.companySize = req.body.companySize;
                prospect.websiteUrl = req.body.websiteUrl;
                prospect.mailSent = req.body.mailSent;
                prospect.followupDate = req.body.followupDate;
                prospect.message = req.body.message;
                prospect.updatedBy = req.auth.credentials.id;
                prospect.save(function (err, prospect) {
                    res.status(200).send({
                        success: true,
                        message: 'success',
                        data: prospect
                    });
                });
            } else {
                res.status(404).send({
                    success: false,
                    message: 'Data not found',
                    data: null
                });
            }
        });
    },

    getProspectDetail: function(req, res) {
        Prospect.findOne({_id: req.params.id}).populate('cxo').populate('section').populate('creator').then((prospect) => {
            if (prospect) {
                res.status(200).send({
                    success: true,
                    message: 'success',
                    data: prospect
                });
            } else {
                res.status(404).send({
                    success: false,
                    message: 'Data not found',
                    data: null
                });
            }
        });
    },

    removeProspect: function(req, res) {
        Prospect.findOneAndRemove({_id: req.params.id}).then((prospect) => {
            if (prospect) {
                res.status(200).send({
                    success: true,
                    message: 'Success',
                    data: prospect
                });
            } else {
                res.status(404).send({
                    success: false,
                    message: 'Data not found',
                    data: null
                });
            }
        });
    },

    moveToLead: function(req, res) {
        var category = req.body.category;
        Prospect.findOneAndUpdate({_id: req.params.id}, {$set: {category: category, updatedBy: req.auth.credentials.id} }).then((contact) => {
            if (contact) {
                res.status(200).send({
                    success: true,
                    message: 'Category updated successfully',
                    data: []
                });
            } else {
                res.status(404).send({
                    success: false,
                    message: 'No data found',
                    data: null
                });
            }
        });
    }
};
