/*******************************************************************************
 * WebProspect Model
 ******************************************************************************/
'use strict';
var mongoose = require('mongoose'),
    Schema = mongoose.Schema,
    timestamps = require('mongoose-timestamps'),
    uniqueValidator = require('mongoose-unique-validator');
const Config = require('../config/config');

var callPlanSchema = new Schema({
    date: { type: Date, default: null },
    time: {type: String, default: null },
    clientTimeZone: { type: String, default: null },
    duration: { type: String, default: null }
});

//Define WebProspect Schema
var WebProspectSchema = new Schema({
    name: { type: String, required: true },
    email: { type: String, lowercase: true, required: true},
    mobile: { type: String, default: null },
    dob: { type: Date, default: null },
    gender: { type: String, default: null },
    budget: { type: String, default: null },
    address: { type: String, default: null },
    city: { type: String, default: null },
    state: { type: String, default: null },
    country: { type: String, default: null },
    zip: { type: String, default: null },
    message: { type: String, default: null },
    websiteUrl: { type: String, default: null },
    category: { type: String, default: 'contact', enum: ['contact', 'appointment', 'prospect', 'lead', 'client'] },
    title: { type: String, required: true, default: null },
    message: { type: String, required: true, default: null },
    joinFrom: { type: String, default: 'Main Huulke', enum: Config.platformFrom },
    joinFromType: { type: String, default: null }, //Home, Contacts, Report, Popup
    language: { type: String, default: 'en', enum:  Config.languages},
    acceptedNewsLetter: { type: Boolean, default: false, enum: [true, false] },
    acceptedCommercialStuff: { type: Boolean, default: false, enum: [true, false] },
    callPlan: { type: callPlanSchema, default: callPlanSchema },
    isDeleted: { type: Number, default: 0, enum: [1, 0] }, //1=> Deleted 0=>Not Deleted
    createdAt: Date,
    updatedAt: Date
});

//middle ware in serial
WebProspectSchema.pre('save', function (next) {
    this.updated_at = Date.now();
    if(this.name)
        this.name = this.name.charAt(0).toUpperCase() + this.name.slice(1);
    if(this.email)
        this.email = this.email.toLowerCase();
    next();
});


// Add timestamp plugin
WebProspectSchema.plugin(timestamps, { index: true });
WebProspectSchema.plugin(uniqueValidator, { message: 'The `{VALUE}` already taken' });
module.exports = mongoose.model('WebProspect', WebProspectSchema);
