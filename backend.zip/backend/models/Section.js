/*******************************************************************************
 * Section Model
 ******************************************************************************/
'use strict';
var mongoose = require('mongoose'),
    Schema = mongoose.Schema,
    timestamps = require('mongoose-timestamps'),
    uniqueValidator = require('mongoose-unique-validator');

//Define Section Schema
var SectionSchema = new Schema({
    name: { type: String, required: true, index: true },
    description: { type: String, default: null },
    createdAt: Date,
    updatedAt: Date
});

//middle ware in serial
SectionSchema.pre('save', function (next) {
    this.updated_at = Date.now();
    if(this.name)
        this.name = this.name.charAt(0).toUpperCase() + this.name.slice(1);
    next();
});

// Add timestamp plugin
SectionSchema.plugin(timestamps, { index: true });
SectionSchema.plugin(uniqueValidator, { message: 'The `{VALUE}` already taken' });
module.exports = mongoose.model('Section', SectionSchema);
