/*******************************************************************************
 * User Model
 ******************************************************************************/
'use strict';
var mongoose = require('mongoose'),
    Schema = mongoose.Schema,
    timestamps = require('mongoose-timestamps');

var modulePermissionSchema = new Schema({
    selected: { type: Boolean, default: false, enum: [true, false] },
    key: { type: String, required: true },
    name: { type: String, required: true },
    permissions: { type: Schema.Types.Mixed }
});

var pictureSizeSchema = new Schema({
    small: {type: String, default: null},
    original: {type: String, default: null}
});

var currentAddressSchema = new Schema({
    address: {type: String, default: null},
    city: {type: String, default: null},
    state: {type: String, default: null},
    country: {type: String, default: null},
    zip: {type: String, default: null}
});

var permanentAddressSchema = new Schema({
    address: {type: String, default: null},
    city: {type: String, default: null},
    state: {type: String, default: null},
    country: {type: String, default: null},
    zip: {type: String, default: null}
});

var SalaryStructureSchema = new Schema({
    basic: { type: Number, default: 0 }, //50% of all salary
    hra: { type: Number, default: 0 }, //50% of basic
    lta: { type: Number, default: 0 }, //Leave Travel Allowance which includes family Spouse, Children, Parents
    travelAllowance: { type: Number, default: 0 }, // Travel/Tranportation Allowance max 1600
    specialAllowance: { type: Number, default: 0 },
    medicalReimbursement: { type: Number, default: 0 },
    foodReimbursement: { type: Number, default: 0 },
    bookAndPeriodicals: { type: Number, default: 0 },
    studyChagres: { type: Number, default: 0 },
    uniformAllowance: { type: Number, default: 0 },
    mobileAndInternet: { type: Number, default: 0 }
});

var BankDetailSchema = new Schema({
    accountNumber: { type: String, default: null },
    bankName: { type: String, default: null },
    branch: { type: String, default: null },
    address: { type: String, default: null },
});

//Define User schema
var UserSchema = new Schema({
    fullName: { type: String, default: null },
    empCode: { type: String, default: 'HLK-0' },
    userId: { type: Number, default: 0 },
    email: { type: String, required: true, unique: true, lowercase: true, index: true },
    password: { type: String, trim: true, required: true }, //select: false
    userType: { type: Number, default: 1, enum: [1, 2] }, // 1=>Admin User, 2=>Normal user
    adminType: { type: Number, default: 1, enum: [1, 2] },
    mobile: { type: String, default: null, index: true },
    emailVerifyToken: { type: String, default: null },
    forgotPasswordToken: { type: String, default: null },
    isEmailVerified: { type: Boolean, default: false, enum: [true, false] },
    isMobileVerified: { type: Boolean, default: false, enum: [true, false] },
    dob: { type: Date, default: null },
    gender: { type: String, default: 'm', enum: ['m', 'f'] },
    fatherName: { type: String, default: null },
    fatherContactNumber: { type: String, default: null },
    joiningPosition: { type: String, default: null },
    position: { type: String, default: null },
    leavingTimePosition: { type: Date, default: null },
    pencardNumber: { type: String, default: null },
    PFNumber: { type: String, default: null },
    PFUANNumber: { type: String, default: null },
    ESIAccNumber: { type: String, default: null },
    adharcardNumber: { type: String, default: null },
    salary: { type: String, default: 0 }, //Salary Yearly
    joiningDate: { type: Date, default: null },
    leavingDate: { type: Date, default: null },
    salaryStructure: { type: SalaryStructureSchema },
    bankDetails: { type: BankDetailSchema },
    currentAddress: { type: currentAddressSchema, default: currentAddressSchema },
    permanentAddress: { type: permanentAddressSchema, default: permanentAddressSchema },
    picture: { type: pictureSizeSchema, default: pictureSizeSchema },
    modulesAndpermissions: [{ type: modulePermissionSchema, default: []}],
    createdAt: Date,
    updatedAt: Date
});

//middle ware in serial
UserSchema.pre('save', function (next) {
    this.updated_at = Date.now();
    if(this.fullName)
        this.fullName = this.fullName.charAt(0).toUpperCase() + this.fullName.slice(1);
    next();
});

// Add timestamp plugin
UserSchema.plugin(timestamps, { index: true });

module.exports = mongoose.model('User', UserSchema);
