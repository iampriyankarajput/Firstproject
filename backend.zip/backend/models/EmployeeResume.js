/*******************************************************************************
 * EmployeeResume Model
 ******************************************************************************/
'use strict';
var mongoose = require('mongoose'),
    Schema = mongoose.Schema,
    timestamps = require('mongoose-timestamps');
    const Config = require('../config/config');
//Define EmployeeResume Schema
var EmployeeResumeSchema = new Schema({
    name: { type: String, required: true, index: true },
    email: { type: String, lowercase: true, required: true, index: true },
    mobile: { type: String, required: true },
    message: { type: String, required: true },
    language: { type: String, default: 'en', enum:  Config.languages},
    appliedFor: {type: Schema.Types.ObjectId, ref: 'OpeningJob', required: true },
    resume: { type: String, required: true },
    status: { type: Number, default: 0, enum: [0, 1, 2, 3] }, // 0=> Submitted, 1=> Considered, 2=> On Hold, 3=> Rejected
    createdAt: Date,
    updatedAt: Date
});

//middle ware in serial
EmployeeResumeSchema.pre('save', function (next) {
    this.updated_at = Date.now();
    if(this.name)
        this.name = this.name.charAt(0).toUpperCase() + this.name.slice(1);
    if(this.email)
        this.email = this.email.toLowerCase();
    next();
});
// Add timestamp plugin
EmployeeResumeSchema.plugin(timestamps, { index: true });
module.exports = mongoose.model('EmployeeResume', EmployeeResumeSchema);
