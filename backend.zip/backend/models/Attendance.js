/*******************************************************************************
 * Attendance Model
 ******************************************************************************/
'use strict';
var mongoose = require('mongoose'),
    Schema = mongoose.Schema,
    timestamps = require('mongoose-timestamps');

//Define Attendance Schema
var AttendanceSchema = new Schema({
    user: { type: Schema.Types.ObjectId, ref: 'User', required: true },
    userId: { type: Number, required: true },
    year: { type: String, required: true },
    month: { type: String, required: true },
    date: Date,
    day: { type: String, required: true },
    arrivalTime: { type: String,  default: '00:00' },
    leavingTime: { type: String,  default: '00:00' },
    mode: { type: String, default: 'off', enum: ['on', 'off', 'holiday'] },
    leaveType: { type: String, default: 'W', enum: ['W', 'FD', 'HD', 'SL'] },
    isApproved: { type: Boolean, default: false, enum: [true, false] },
    isPaid: { type: Boolean, default: false, enum: [true, false] },
    createdAt: Date,
    updatedAt: Date
});

//middle ware in serial
AttendanceSchema.pre('save', function (next) {
    this.updated_at = Date.now();
    next();
});

// Add timestamp plugin
AttendanceSchema.plugin(timestamps, { index: true });
module.exports = mongoose.model('Attendance', AttendanceSchema);
