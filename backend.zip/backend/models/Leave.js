/*******************************************************************************
 * Leave Model
 ******************************************************************************/
'use strict';
var mongoose = require('mongoose'),
    Schema = mongoose.Schema,
    timestamps = require('mongoose-timestamps');

var EarnedLeaveSchema = new Schema({
    month: { type: String, required: true },
    title: { type: String, required: true },
    value: { type: Number, default: 1.5 }
});

var ConsumedLeaveSchema = new Schema({
    date: Date,
    leaveType: { type: String, default: 'FD', enum: ['FD', 'HD', 'SL'] },
    isPaid: { type: Boolean, default: false, enum: [true, false] },
    value: { type: Number, default: 1 } //1=> FullDay, 0.5 => Half Day, 0.25 => Shoart leave
});

var AppliedLeaveSchema = new Schema({
    leaveDate: Date,
    leaveType: { type: String, default: 'FD', enum: ['FD', 'HD', 'SL'] },
    status: { type: Number, default: 0, enum: [0, 1, 2] }, //0=> Applied, 1=> Approved, 2=> Un Approved/Unpaid, 3=> Cancelled
    reason: { type: String, default: '' },
    value: { type: Number, default: 1 } //1=> FullDay, 0.5 => Half Day, 0.25 => Shoart leave
});

//Define Leave Schema
var LeaveSchema = new Schema({
    user: { type: Schema.Types.ObjectId, ref: 'User', required: true },
    year: { type: String, required: true },
    previous: { type: Number, default: 0 },
    earned: [{ type: EarnedLeaveSchema }],
    consumed: [{ type: ConsumedLeaveSchema }],
    remaining: { type: Number, default: 0 },
    applied: [{ type: AppliedLeaveSchema }],
    createdAt: Date,
    updatedAt: Date
});

//middle ware in serial
LeaveSchema.pre('save', function (next) {
    this.updated_at = Date.now();
    next();
});

// Add timestamp plugin
LeaveSchema.plugin(timestamps, { index: true });
module.exports = mongoose.model('Leave', LeaveSchema);
