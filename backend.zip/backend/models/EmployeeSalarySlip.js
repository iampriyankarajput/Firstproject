/*******************************************************************************
 * EmployeeSalarySlip Model
 ******************************************************************************/
'use strict';
var mongoose = require('mongoose'),
    Schema = mongoose.Schema,
    timestamps = require('mongoose-timestamps');

var DeductionSchema = new Schema({
    pf: { type: Number, default: 0 },
    tds: { type: Number, default: 0 }
});

//Define EmployeeSalarySlip Schema
var EmployeeSalarySlipSchema = new Schema({
    user: { type: Schema.Types.ObjectId, ref: 'User', required: true },
    year: { type: Number, required: true },
    month: { type: Number, required: true },
    mainSalary: { type: Number, required: true },
    basic: { type: Number, required: true }, //50% of all salary
    hra: { type: Number, required: true }, //50% of basic
    lta: { type: Number, default: 0 }, //Leave Travel Allowance which includes family Spouse, Children, Parents
    travelAllowance: { type: Number, default: 0 }, // Travel/Tranportation Allowance max 1600
    specialAllowance: { type: Number, default: 0 },
    medicalReimbursement: { type: Number, default: 0 },
    foodReimbursement: { type: Number, default: 0 },
    bookAndPeriodicals: { type: Number, default: 0 },
    studyChagres: { type: Number, default: 0 },
    uniformAllowance: { type: Number, default: 0 },
    mobileAndInternet: { type: Number, default: 0 },
    bonus: { type: Number, default: 0 },
    deductions: { type: DeductionSchema },
    earnedSalary: { type: Number, required: true },
    createdAt: Date,
    updatedAt: Date
});

//middle ware in serial
EmployeeSalarySlipSchema.pre('save', function (next) {
    this.updated_at = Date.now();
    next();
});

// Add timestamp plugin
EmployeeSalarySlipSchema.plugin(timestamps, { index: true });
module.exports = mongoose.model('EmployeeSalarySlip', EmployeeSalarySlipSchema);
