/*******************************************************************************
 * EmployeeSalary Model
 ******************************************************************************/
'use strict';
var mongoose = require('mongoose'),
    Schema = mongoose.Schema,
    timestamps = require('mongoose-timestamps');

//Define EmployeeSalary Schema
var EmployeeSalarySchema = new Schema({
    user: { type: Schema.Types.ObjectId, ref: 'User', required: true },
    year: { type: String, required: true },
    month: { type: String, required: true },
    createdAt: Date,
    updatedAt: Date
});

//middle ware in serial
EmployeeSalarySchema.pre('save', function (next) {
    this.updated_at = Date.now();
    next();
});

// Add timestamp plugin
EmployeeSalarySchema.plugin(timestamps, { index: true });
module.exports = mongoose.model('EmployeeSalary', EmployeeSalarySchema);
