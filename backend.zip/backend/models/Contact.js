/*******************************************************************************
 * Contact Model
 ******************************************************************************/
'use strict';
var mongoose = require('mongoose'),
    Schema = mongoose.Schema,
    timestamps = require('mongoose-timestamps');
const Config = require('../config/config');
//Define Contact Schema
var ContactSchema = new Schema({
    name: { type: String, required: true, index: true },
    email: { type: String, lowercase: true, required: true, index: true },
    mobile: { type: String, required: true },
    company: { type: String, default: null },
    address: { type: String, default: null },
    city: { type: String, default: null },
    state: { type: String, default: null },
    country: { type: String, default: null },
    zip: { type: String, default: null },
    websiteUrl: { type: String, default: null },
    title: { type: String, required: true, default: null },
    message: { type: String, required: true, default: null },
    contactType: { type: String, default: 'Other', enum: ['Employee', 'Client', 'Media Inquiry', 'Vendor Enrolment', 'Other'] },
    joinFrom: { type: String, default: 'Main Huulke', enum: Config.platformFrom },
    joinFromType: { type: String, default: null }, //Home, Contacts, Report, Popup
    language: { type: String, default: 'en', enum:  Config.languages},
    acceptedTNC: { type: Boolean, default: false, enum: [true, false] },
    acceptedPNP: { type: Boolean, default: false, enum: [true, false] },
    isReplied: { type: Boolean, default: false, enum: [true, false] }, // true=> Replied, false=> Not replied
    createdAt: Date,
    updatedAt: Date
});

//middle ware in serial
ContactSchema.pre('save', function (next) {
    this.updated_at = Date.now();
    if(this.name)
        this.name = this.name.charAt(0).toUpperCase() + this.name.slice(1);
    if(this.email)
        this.email = this.email.toLowerCase();
    next();
});
// Add timestamp plugin
ContactSchema.plugin(timestamps, { index: true });
module.exports = mongoose.model('Contact', ContactSchema);
