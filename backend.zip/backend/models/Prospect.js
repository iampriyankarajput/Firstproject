/*******************************************************************************
 * Prospect Model
 ******************************************************************************/
'use strict';
var mongoose = require('mongoose'),
    Schema = mongoose.Schema,
    timestamps = require('mongoose-timestamps'),
    uniqueValidator = require('mongoose-unique-validator');

//Define Industry schema
var industrySchema = new Schema({
    key: { type: String, default: null },
    name: { type: String, default: null }
});

//Define Industry schema
var companySizeSchema = new Schema({
    key: { type: String, default: null },
    name: { type: String, default: null }
});


//Define Prospect Schema
var ProspectSchema = new Schema({
    cxo: {type: Schema.Types.ObjectId, ref: 'Cxo', required: true },
    name: { type: String, required: true },
    email: { type: String, lowercase: true, required: true},
    mobile: { type: String, default: null },
    section: {type: Schema.Types.ObjectId, ref: 'Section', required: true },
    address: { type: String, default: null },
    city: { type: String, default: null },
    state: { type: String, default: null },
    country: { type: String, default: null },
    zip: { type: String, default: null },
    message: { type: String, default: null },
    websiteUrl: { type: String, required: true, index: true },
    category: { type: String, default: 'prospect', enum: ['prospect', 'lead', 'client'] },
    mailSent: { type: Number, default: 0, enum: [0, 1] }, //0=>Not sent, 1=> Mail sent
    isDeleted: { type: Number, default: 0, enum: [1, 0] }, //1=> Deleted 0=>Not Deleted
    followupDate: Date,
    creator: {type: Schema.Types.ObjectId, ref: 'User', required: true },
    updatedBy: {type: Schema.Types.ObjectId, ref: 'User', required: true },
    industry: { type: Schema.Types.Mixed },
    companySize: { type: Schema.Types.Mixed },
    createdAt: Date,
    updatedAt: Date
});

//middle ware in serial
ProspectSchema.pre('save', function (next) {
    this.updated_at = Date.now();
    if(this.name)
        this.name = this.name.charAt(0).toUpperCase() + this.name.slice(1);
    if(this.email)
        this.email = this.email.toLowerCase();
    next();
});


// Add timestamp plugin
ProspectSchema.plugin(timestamps, { index: true });
ProspectSchema.plugin(uniqueValidator, { message: 'The `{VALUE}` already taken' });
module.exports = mongoose.model('Prospect', ProspectSchema);
