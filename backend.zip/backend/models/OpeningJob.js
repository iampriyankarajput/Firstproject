/*******************************************************************************
 * OpeningJob Model
 ******************************************************************************/
'use strict';
var mongoose = require('mongoose'),
    Schema = mongoose.Schema,
    timestamps = require('mongoose-timestamps');
    const Config = require('../config/config');
//Define OpeningJobSchema Schema
var OpeningJobSchema = new Schema({
    title: { type: String, required: true },
    openings: { type: Number, default: 1 },
    experience: { type: String, required: true },
    location: { type: String, required: true },
    desciption: { type: String, required: true },
    language: { type: String, default: 'en', enum:  Config.languages},
    status: { type: Number, default: 1, enum: [0, 1] }, // 1=> Open, 0=> Closed
    createdAt: Date,
    updatedAt: Date
});

//middle ware in serial
OpeningJobSchema.pre('save', function (next) {
    this.updated_at = Date.now();
    if(this.name)
        this.name = this.name.charAt(0).toUpperCase() + this.name.slice(1);
    if(this.email)
        this.email = this.email.toLowerCase();
    next();
});
// Add timestamp plugin
OpeningJobSchema.plugin(timestamps, { index: true });
module.exports = mongoose.model('OpeningJob', OpeningJobSchema);
