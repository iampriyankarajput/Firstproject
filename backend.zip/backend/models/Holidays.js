/*******************************************************************************
 * Holidays Model
 ******************************************************************************/
'use strict';
var mongoose = require('mongoose'),
    Schema = mongoose.Schema,
    timestamps = require('mongoose-timestamps'),
    uniqueValidator = require('mongoose-unique-validator');

var LeaveDaySchema = new Schema({
    date: { type: String, required: true },
    title: { type: String, required: true },
    type: { type: String, default: 'holiday', enum: ['holiday', 'floating', 'other'] },
    description: { type: String, default: null },
});

//Define Holidays Schema
var HolidaysSchema = new Schema({
    year: { type: String, required: true },
    company: { type: String, default: 'Huulke Srl.' },
    branch: { type: String, default: 'Huulke Technologies India Private Limited' },
    description: { type: String, default: null },
    holidays: [{ type: LeaveDaySchema }],
    createdAt: Date,
    updatedAt: Date
});

//middle ware in serial
HolidaysSchema.pre('save', function (next) {
    this.updated_at = Date.now();
    next();
});

// Add timestamp plugin
HolidaysSchema.plugin(timestamps, { index: true });
module.exports = mongoose.model('Holidays', HolidaysSchema);
