/*******************************************************************************
 * Holidays Routes
 ******************************************************************************/
'use strict';
const express = require('express')
const router = express.Router()
const validator = require('express-joi-validator');
const HolidaysController = require('../controllers/HolidaysController');
const HolidaySchema = require('../validations/holiday-schema');
const auth = require('../helpers/auth').validate;
const accessRule = require('../helpers/auth').accessRule;

module.exports = function(app) {
    app.get('/api/holidays', auth, accessRule, function(req, res) {
        HolidaysController.getHolidays(req, res);
    });

    app.post('/api/holidays/:year', auth, accessRule, validator(HolidaySchema.holidayData), function(req, res) {
        HolidaysController.addHolidays(req, res);
    });

    app.put('/api/holidays/:year', auth, accessRule, function(req, res) {
        HolidaysController.updateHolidays(req, res);
    });
};
