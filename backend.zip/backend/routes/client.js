/*******************************************************************************
 * Admin Routes
 ******************************************************************************/
'use strict';
const express = require('express')
const router = express.Router()
const ClientController = require('../controllers/ClientController');
const auth = require('../helpers/auth').validate;
const accessRule = require('../helpers/auth').accessRule;

module.exports = function(app) {
    app.get('/api/clients', auth, accessRule, function(req, res) {
        ClientController.getClients(req, res);
    });

    app.get('/api/client/:id', auth, accessRule, function(req, res) {
        ClientController.getClientDetail(req, res);
    });
};
