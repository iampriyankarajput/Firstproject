/*******************************************************************************
 * Attendance Routes
 ******************************************************************************/
'use strict';
const express = require('express');
const router = express.Router();
const AttendanceController = require('../controllers/AttendanceController');
const auth = require('../helpers/auth').validate;
const accessRule = require('../helpers/auth').accessRule;

module.exports = function(app) {
    app.get('/api/attendance', auth, accessRule, function(req, res) {
        AttendanceController.getEmployeeAttendance(req, res);
    });

    app.get('/api/allattendance', auth, accessRule, function(req, res) {
        AttendanceController.getAllEmployeeAttendance(req, res);
    });

    app.put('/api/allattendance/mark', auth, accessRule, function(req, res) {
        AttendanceController.markAttendanceStatus(req, res);
    });

    app.put('/api/allattendance/update', auth, accessRule, function(req, res) {
        AttendanceController.updateAttendanceStatus(req, res);
    });
};
