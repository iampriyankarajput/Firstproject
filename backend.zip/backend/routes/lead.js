/*******************************************************************************
 * Admin Routes
 ******************************************************************************/
'use strict';
const express = require('express')
const router = express.Router()
const LeadController = require('../controllers/LeadController');
const auth = require('../helpers/auth').validate;
const accessRule = require('../helpers/auth').accessRule;

module.exports = function(app) {
    app.get('/api/leads', auth, accessRule, function(req, res) {
        LeadController.getLeads(req, res);
    });

    app.get('/api/lead/:id', auth, accessRule, function(req, res) {
        LeadController.getLeadDetail(req, res);
    });
};
