/*******************************************************************************
 * Contact Routes
 ******************************************************************************/
'use strict';
const express = require('express');
const router = express.Router();
const validator = require('express-joi-validator');
const ContactSchema = require('../validations/contact-schema');
const ContactController = require('../controllers/ContactController');
const auth = require('../helpers/auth').validate;

module.exports = function(app) {

    app.post('/api/contact', validator(ContactSchema.addContact), function(req, res, next) {
        ContactController.addContact(req, res);
    });

    app.get('/api/contact', auth, function(req, res) {
        ContactController.getContacts(req, res);
    });

    app.get('/api/contact/:id', auth, function(req, res) {
        ContactController.getContactDetail(req, res);
    });

    app.delete('/api/contact/:id', auth, function(req, res) {
        ContactController.removeContact(req, res);
    });

    app.post('/api/web/contact', validator(ContactSchema.addWebContact), function(req, res, next) {
        ContactController.addWebContact(req, res);
    });

    app.put('/api/web/contact/callplan/:id', validator(ContactSchema.addCallPlan), function(req, res, next) {
        ContactController.addWebContactCallPlan(req, res);
    });

    app.get('/api/web/contact', auth, function(req, res) {
        ContactController.getWebContacts(req, res);
    });

    app.get('/api/web/contact/:id', auth, function(req, res) {
        ContactController.getWebContactDetail(req, res);
    });

    app.delete('/api/web/contact/:id', auth, function(req, res) {
        ContactController.removeWebContact(req, res);
    });

    app.put('/api/web/contact/:id/move', auth, validator(ContactSchema.moveProspect), function(req, res, next) {
        ContactController.moveToLead(req, res);
    });
};
