/*******************************************************************************
 * Admin Routes
 ******************************************************************************/
'use strict';
const express = require('express');
const router = express.Router();
const validator = require('express-joi-validator');
const ContactSchema = require('../validations/contact-schema');
const ProspectController = require('../controllers/ProspectController');
const auth = require('../helpers/auth').validate;
const accessRule = require('../helpers/auth').accessRule;

module.exports = function(app) {
    app.get('/api/cxo', auth, function(req, res) {
        ProspectController.getCxos(req, res);
    });

    app.get('/api/cxo/:id', auth, function(req, res) {
        ProspectController.getCxosDetail(req, res);
    });

    app.post('/api/cxo', auth, function(req, res) {
        ProspectController.addCxos(req, res);
    });

    app.put('/api/cxo/:id', auth, function(req, res) {
        ProspectController.updateCxos(req, res);
    });

    app.delete('/api/cxo/:id', auth, function(req, res) {
        ProspectController.removeCxos(req, res);
    });

    app.get('/api/prospects', auth, accessRule, function(req, res) {
        ProspectController.getProspects(req, res);
    });

    app.get('/api/prospect/:id', auth, accessRule, function(req, res) {
        ProspectController.getProspectDetail(req, res);
    });

    app.post('/api/prospect/import/excel', auth, function(req, res) {
        ProspectController.importExcelFile(req, res);
    });

    app.post('/api/prospect', auth, accessRule, function(req, res) {
        ProspectController.addProspect(req, res);
    });

    app.put('/api/prospect/:id', auth, accessRule, function(req, res) {
        ProspectController.updateProspect(req, res);
    });

    app.delete('/api/prospect/:id', auth, accessRule, function(req, res) {
        ProspectController.removeProspect(req, res);
    });

    app.put('/api/prospect/:id/move', auth, validator(ContactSchema.moveProspect), function(req, res, next) {
        ProspectController.moveToLead(req, res);
    });
};
