/*******************************************************************************
 * Leave Routes
 ******************************************************************************/
'use strict';
const express = require('express');
const router = express.Router();
const validator = require('express-joi-validator');
const LeaveSchema = require('../validations/leave-schema');
const LeaveController = require('../controllers/LeaveController');
const auth = require('../helpers/auth').validate;
const accessRule = require('../helpers/auth').accessRule;

module.exports = function(app) {
    app.get('/api/leave/create', function(req, res) {
        LeaveController.createLeaves(req, res);
    });

    app.get('/api/leave/earned', function(req, res) {
        LeaveController.earnedLeave(req, res);
    });

    app.get('/api/leave', auth, accessRule, function(req, res) {
        LeaveController.getLeaves(req, res);
    });

    app.post('/api/leave', auth, accessRule, validator(LeaveSchema.applyLeave), function(req, res) {
        LeaveController.applyLeave(req, res);
    });

    app.delete('/api/leave/:id', auth, accessRule, function(req, res) {
        LeaveController.removeLeave(req, res);
    });

    app.get('/api/salary', auth, accessRule, function(req, res) {
        LeaveController.getSalarySlips(req, res);
    });
};
