/*******************************************************************************
 * Admin Routes
 ******************************************************************************/
'use strict';
const express = require('express')
const router = express.Router()
const UserController = require('../controllers/UserController');
const auth = require('../helpers/auth').validate;
const accessRule = require('../helpers/auth').accessRule;
//const UserSchema = require('../validations/user-schema');
module.exports = function(app) {
    app.get('/api/modules', auth, function(req, res) {
        UserController.getModuleList(req, res);
    });

    app.post('/login', function(req, res) {
        UserController.login(req, res);
    });

    app.post('/api/admin/create', function(req, res) {
        UserController.createSuperAdmin(req, res);
    });

    app.get('/api/user/profile', auth, function(req, res) {
        UserController.getProfile(req, res);
    });

    app.put('/api/user/profile', auth, function(req, res) {
        UserController.updateProfile(req, res);
    });

    app.get('/api/user', auth, accessRule, function(req, res) {
        UserController.getUserList(req, res);
    });

    app.post('/api/user', auth, accessRule, function(req, res) {
        UserController.createUser(req, res);
    });

    app.get('/api/user/:id', auth, function(req, res) {
        UserController.getUserProfile(req, res);
    });

    app.get('/api/user/attendance/:id', auth, accessRule, function(req, res) {
        UserController.getEmployeeAttendances(req, res);
    });

    app.get('/api/user/leave/detail/:id', auth, accessRule, function(req, res) {
        UserController.getEmployeeLeaves(req, res);
    });

    app.put('/api/user/salary/:id', auth, accessRule, function(req, res) {
        UserController.updateUserSalaryStructure(req, res);
    });

    app.put('/api/user/bank/:id', auth, accessRule, function(req, res) {
        UserController.updateUserBankDetail(req, res);
    });

    app.put('/api/user/:id', auth, accessRule, function(req, res) {
        UserController.updateUser(req, res);
    });

    app.put('/api/change/password', auth, function(req, res) {
        UserController.changePassword(req, res);
    });

    app.delete('/api/user/:id', auth, accessRule, function(req, res) {
        UserController.removeUser(req, res);
    });

    app.get('/api/user/list/filter', auth, function(req, res) {
        UserController.getUserListForFilter(req, res);
    });

    app.get('/api/section', auth, function(req, res) {
        UserController.getSections(req, res);
    });

    app.get('/api/section/:id', auth, function(req, res) {
        UserController.getSectionDetail(req, res);
    });

    app.post('/api/section', auth, function(req, res) {
        UserController.addSection(req, res);
    });

    app.put('/api/section/:id', auth, accessRule, function(req, res) {
        UserController.updateSection(req, res);
    });
};
