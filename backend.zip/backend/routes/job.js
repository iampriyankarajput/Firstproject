/*******************************************************************************
 * Employee Job Routes
 ******************************************************************************/
'use strict';
const express = require('express');
const router = express.Router();
const multer  = require('multer');
const multipart = require('connect-multiparty');
const multipartMiddleware = multipart();
const EmployeeJobController = require('../controllers/EmployeeJobController');
const auth = require('../helpers/auth').validate;
const accessRule = require('../helpers/auth').accessRule;
const validator = require('express-joi-validator');
const JobResumeSchema = require('../validations/job-resume-schema');
const upload = multer({ dest: 'uploads/' });

module.exports = function(app) {
    app.post('/api/job', auth, accessRule, validator(JobResumeSchema.createJob), function(req, res) {
        EmployeeJobController.addJob(req, res);
    });

    app.put('/api/job/:id', auth, accessRule, validator(JobResumeSchema.updateJob), function(req, res) {
        EmployeeJobController.UpdateJob(req, res);
    });

    app.get('/api/job/admins', function(req, res) {
        EmployeeJobController.getJobs(req, res);
    });

    app.get('/api/job', function(req, res) {
        EmployeeJobController.getJobsForWeb(req, res);
    });

    app.delete('/api/job/:id', function(req, res) {
        EmployeeJobController.deleteJob(req, res);
    });

    app.get('/api/job/:id', function(req, res) {
        EmployeeJobController.getJobDetail(req, res);
    });

    app.post('/api/job/apply', upload.single('resume'), function(req, res) {
        EmployeeJobController.applyForJob(req, res);
    });

    app.get('/api/resume', auth, accessRule, function(req, res) {
        EmployeeJobController.getResumes(req, res);
    });
};
